import audio from "@ohos:multimedia.audio";
import type { BusinessError } from "@ohos:base";
import fileIo from "@ohos:file.fs";
import { FileUtils } from "@normalized:N&&&entry/src/main/ets/utils/FileUtils&";
const TAG = 'AudioCapturerDemo';
class Options {
    offset?: number;
    length?: number;
}
let context = getContext(this);
let bufferSize: number = 0;
let audioCapturer: audio.AudioCapturer | undefined = undefined;
let audioStreamInfo: audio.AudioStreamInfo = {
    samplingRate: audio.AudioSamplingRate.SAMPLE_RATE_48000,
    channels: audio.AudioChannel.CHANNEL_2,
    sampleFormat: audio.AudioSampleFormat.SAMPLE_FORMAT_S16LE,
    encodingType: audio.AudioEncodingType.ENCODING_TYPE_RAW // 编码格式
};
let audioCapturerInfo: audio.AudioCapturerInfo = {
    source: audio.SourceType.SOURCE_TYPE_MIC,
    capturerFlags: 0 // 音频采集器标志
};
let audioCapturerOptions: audio.AudioCapturerOptions = {
    streamInfo: audioStreamInfo,
    capturerInfo: audioCapturerInfo
};
// let path = getContext().cacheDir;
// let filePath = path + '/StarWars10s-2C-48000-4SW.wav';
let file: fileIo.File;
/**
 * 创建音频文件，并打开
 * @param userId
 */
function initFile(userId: string) {
    let filePath = FileUtils.createAudioFile(userId);
    file = fileIo.openSync(filePath, fileIo.OpenMode.READ_WRITE);
    return filePath;
}
let readDataCallback = (buffer: ArrayBuffer) => {
    let options: Options = {
        offset: bufferSize,
        length: buffer.byteLength
    };
    fileIo.writeSync(file.fd, buffer, options);
    bufferSize += buffer.byteLength;
};
// 初始化，创建实例，设置监听事件
function init() {
    audio.createAudioCapturer(audioCapturerOptions, (err, capturer) => {
        if (err) {
            console.error(`Invoke createAudioCapturer failed, code is ${err.code}, message is ${err.message}`);
            return;
        }
        console.info(`${TAG}: create AudioCapturer success`);
        audioCapturer = capturer;
        if (audioCapturer !== undefined) {
            (audioCapturer as audio.AudioCapturer).on('readData', readDataCallback);
        }
    });
}
// 开始一次音频采集
function start() {
    if (audioCapturer !== undefined) {
        let stateGroup = [audio.AudioState.STATE_PREPARED, audio.AudioState.STATE_PAUSED, audio.AudioState.STATE_STOPPED];
        if (stateGroup.indexOf((audioCapturer as audio.AudioCapturer).state.valueOf()) === -1) { // 当且仅当状态为STATE_PREPARED、STATE_PAUSED和STATE_STOPPED之一时才能启动采集
            console.error(`${TAG}: start failed`);
            return;
        }
        // 启动采集
        (audioCapturer as audio.AudioCapturer).start((err: BusinessError) => {
            if (err) {
                console.error('Capturer start failed.');
            }
            else {
                console.info('Capturer start success.');
            }
        });
    }
}
// 停止采集
function stop() {
    if (audioCapturer !== undefined) {
        // 只有采集器状态为STATE_RUNNING或STATE_PAUSED的时候才可以停止
        if ((audioCapturer as audio.AudioCapturer).state.valueOf() !== audio.AudioState.STATE_RUNNING && (audioCapturer as audio.AudioCapturer).state.valueOf() !== audio.AudioState.STATE_PAUSED) {
            console.info('Capturer is not running or paused');
            return;
        }
        //停止采集
        (audioCapturer as audio.AudioCapturer).stop((err: BusinessError) => {
            if (err) {
                console.error('Capturer stop failed.');
            }
            else {
                fileIo.close(file);
                console.info('Capturer stop success.');
            }
        });
    }
}
// 销毁实例，释放资源
function release() {
    if (audioCapturer !== undefined) {
        // 采集器状态不是STATE_RELEASED或STATE_NEW状态，才能release
        if ((audioCapturer as audio.AudioCapturer).state.valueOf() === audio.AudioState.STATE_RELEASED || (audioCapturer as audio.AudioCapturer).state.valueOf() === audio.AudioState.STATE_NEW) {
            console.info('Capturer already released');
            return;
        }
        //释放资源
        (audioCapturer as audio.AudioCapturer).release((err: BusinessError) => {
            if (err) {
                console.error('Capturer release failed.');
            }
            else {
                console.info('Capturer release success.');
            }
        });
    }
}
export { init, start, initFile, stop, release };
