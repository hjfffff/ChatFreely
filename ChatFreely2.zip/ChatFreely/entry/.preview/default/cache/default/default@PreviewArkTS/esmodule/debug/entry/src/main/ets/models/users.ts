export class UserModel {
    /**
     * 用户数据的模型类
     */
    username: string = ''; // ⽤⼾昵称
    avatar: ResourceStr = ''; // 用户头像图片
    id: string = ''; // 用户ID， 唯一区别用户。
    public static initData(): UserModel[] {
        let data: UserModel[] = [{
                username: '妈妈',
                avatar: { "id": 16777278, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" },
                id: '1'
            }, {
                username: '爸爸',
                avatar: { "id": 16777285, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" },
                id: '2'
            }, {
                username: '黄智',
                avatar: { "id": 16777246, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" },
                id: '3'
            }, {
                username: '开学颠沛流离F4（见过周深版',
                avatar: { "id": 16777242, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" },
                id: '4'
            }, {
                username: '21软1何雪婷',
                avatar: { "id": 16777295, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" },
                id: '5'
            }, {
                username: '文件传输助手',
                avatar: { "id": 16777277, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" },
                id: '6'
            }, {
                username: '微信支付',
                avatar: { "id": 16777282, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" },
                id: '7'
            }, {
                username: '订阅号',
                avatar: { "id": 16777233, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" },
                id: '8'
            }, {
                username: '21软件工程本1班',
                avatar: { "id": 16777283, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" },
                id: '9'
            }, {
                username: '通知',
                avatar: { "id": 16777234, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" },
                id: '10'
            }];
        return data;
    }
    public static getCurrentUser(): UserModel {
        const currentUser: UserModel = {
            username: 'hjf',
            avatar: { "id": 16777297, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" },
            id: '2'
        };
        return currentUser;
    }
}
