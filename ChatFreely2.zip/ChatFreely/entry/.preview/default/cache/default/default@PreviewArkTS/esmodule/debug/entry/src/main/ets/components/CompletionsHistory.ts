if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface CompletionsHistory_Params {
    list?: MessageModel[];
}
import emitter from "@ohos:events.emitter";
import router from "@ohos:router";
import type { MessageModel } from '../models/msg';
import { AppStorageUtils } from "@normalized:N&&&entry/src/main/ets/utils/AppStorageUtils&";
import { transTime } from "@normalized:N&&&entry/src/main/ets/utils/DateUtils&";
import { FileUtils } from "@normalized:N&&&entry/src/main/ets/utils/FileUtils&";
class CompletionsHistory extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__list = new ObservedPropertyObjectPU([] // 消息列表，不是来自一个联系人。
        , this, "list");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: CompletionsHistory_Params) {
        if (params.list !== undefined) {
            this.list = params.list;
        }
    }
    updateStateVars(params: CompletionsHistory_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__list.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__list.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __list: ObservedPropertyObjectPU<MessageModel[]>; // 消息列表，不是来自一个联系人。
    get list() {
        return this.__list.get();
    }
    set list(newValue: MessageModel[]) {
        this.__list.set(newValue);
    }
    aboutToAppear(): void {
        this.list = AppStorageUtils.getAllChatLastMessage();
        // 订阅到变化后 更新列表
        emitter.on(AppStorageUtils.chat_key, () => {
            // 当事件发生了，就重新给list赋值。
            this.list = AppStorageUtils.getAllChatLastMessage();
        });
    }
    getDeleteMenuOnListItem(connectUserId: string, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/components/CompletionsHistory.ets(27:5)", "entry");
            Row.height(70);
            Row.padding({
                left: 20,
                right: 20
            });
            Row.backgroundColor({ "id": 16777263, "type": 10001, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" });
            Row.onClick(async () => {
                //删除联系人的所有语音文件
                FileUtils.delUserPath(connectUserId);
                await AppStorageUtils.removeChatAllMessage(connectUserId); // 删除磁盘首选项中的数据
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('删除');
            Text.debugLine("entry/src/main/ets/components/CompletionsHistory.ets(28:7)", "entry");
            Text.fontColor({ "id": 16777276, "type": 10001, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" });
            Text.width(100);
            Text.textAlign(TextAlign.Center);
        }, Text);
        Text.pop();
        Row.pop();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/components/CompletionsHistory.ets(48:5)", "entry");
            Column.height('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            List.create();
            List.debugLine("entry/src/main/ets/components/CompletionsHistory.ets(49:7)", "entry");
            List.divider({
                strokeWidth: 1,
                color: { "id": 16777259, "type": 10001, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" }
            });
            List.padding({
                left: 10,
                right: 20
            });
        }, List);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                {
                    const itemCreation = (elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        itemCreation2(elmtId, isInitialRender);
                        if (!isInitialRender) {
                            ListItem.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    };
                    const itemCreation2 = (elmtId, isInitialRender) => {
                        ListItem.create(deepRenderFunction, true);
                        ListItem.swipeAction({
                            end: () => {
                                // 构建 删除菜单
                                this.getDeleteMenuOnListItem(item.connectUser.id);
                            }
                        });
                        ListItem.padding({
                            top: 10,
                            bottom: 10
                        });
                        ListItem.debugLine("entry/src/main/ets/components/CompletionsHistory.ets(51:11)", "entry");
                    };
                    const deepRenderFunction = (elmtId, isInitialRender) => {
                        itemCreation(elmtId, isInitialRender);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Row.create({ space: 10 });
                            Row.debugLine("entry/src/main/ets/components/CompletionsHistory.ets(52:13)", "entry");
                            Row.onClick(() => {
                                router.pushUrl({
                                    url: 'pages/chat/Chat',
                                    params: item.connectUser
                                });
                            });
                            ViewStackProcessor.visualState("normal");
                            Row.backgroundColor({ "id": 16777276, "type": 10001, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" });
                            ViewStackProcessor.visualState("pressed");
                            Row.backgroundColor({ "id": 16777257, "type": 10001, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" });
                            ViewStackProcessor.visualState();
                        }, Row);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Image.create(item.connectUser.avatar);
                            Image.debugLine("entry/src/main/ets/components/CompletionsHistory.ets(53:15)", "entry");
                            Image.width(50);
                            Image.height(50);
                            Image.borderRadius(4);
                        }, Image);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Column.create({ space: 10 });
                            Column.debugLine("entry/src/main/ets/components/CompletionsHistory.ets(58:15)", "entry");
                            Column.justifyContent(FlexAlign.SpaceBetween);
                            Column.alignItems(HorizontalAlign.Start);
                            Column.height(50);
                            Column.layoutWeight(1);
                            Column.padding({
                                top: 3,
                                bottom: 3
                            });
                        }, Column);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Row.create();
                            Row.debugLine("entry/src/main/ets/components/CompletionsHistory.ets(59:17)", "entry");
                            Row.justifyContent(FlexAlign.SpaceBetween);
                            Row.width('100%');
                        }, Row);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Text.create(item.connectUser.username);
                            Text.debugLine("entry/src/main/ets/components/CompletionsHistory.ets(60:19)", "entry");
                            Text.fontColor({ "id": 16777271, "type": 10001, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" });
                            Text.fontSize(16);
                        }, Text);
                        Text.pop();
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Text.create(transTime(item.sendTime));
                            Text.debugLine("entry/src/main/ets/components/CompletionsHistory.ets(63:19)", "entry");
                            Text.fontSize(12);
                            Text.fontColor({ "id": 16777272, "type": 10001, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" });
                            Text.margin({
                                top: 10
                            });
                        }, Text);
                        Text.pop();
                        Row.pop();
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Text.create(item.messageContent);
                            Text.debugLine("entry/src/main/ets/components/CompletionsHistory.ets(73:17)", "entry");
                            Text.fontColor({ "id": 16777272, "type": 10001, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" });
                            Text.fontSize(14);
                            Text.maxLines(1);
                        }, Text);
                        Text.pop();
                        Column.pop();
                        Row.pop();
                        ListItem.pop();
                    };
                    this.observeComponentCreation2(itemCreation2, ListItem);
                    ListItem.pop();
                }
            };
            this.forEachUpdateFunction(elmtId, this.list, forEachItemGenFunction);
        }, ForEach);
        ForEach.pop();
        List.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
export default CompletionsHistory;
