if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface VoiceInputs_Params {
    voiceStatus?: VoiceStatusEnum //和provide装饰器对应，父组件provide属性改变了，当前子组件也跟着改变
    ;
}
import { VoiceStatusEnum } from "@normalized:N&&&entry/src/main/ets/models/voiceEnum&";
class VoiceInputs extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__voiceStatus = this.initializeConsume("voiceStatus", "voiceStatus");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: VoiceInputs_Params) {
    }
    updateStateVars(params: VoiceInputs_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__voiceStatus.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__voiceStatus.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __voiceStatus: ObservedPropertyAbstractPU<VoiceStatusEnum>; //和provide装饰器对应，父组件provide属性改变了，当前子组件也跟着改变
    get voiceStatus() {
        return this.__voiceStatus.get();
    }
    set voiceStatus(newValue: VoiceStatusEnum //和provide装饰器对应，父组件provide属性改变了，当前子组件也跟着改变
    ) {
        this.__voiceStatus.set(newValue);
    }
    getDisplayContent(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.voiceStatus === VoiceStatusEnum.Cancel) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/components/VoiceInputs.ets(12:7)", "entry");
                        Row.width(100);
                        Row.height(80);
                        Row.borderRadius(20);
                        Row.backgroundColor({ "id": 16777263, "type": 10001, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" });
                        Row.margin({
                            left: 30
                        });
                    }, Row);
                    Row.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.voiceStatus === VoiceStatusEnum.Recording) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/components/VoiceInputs.ets(24:7)", "entry");
                        Row.width(180);
                        Row.height(80);
                        Row.borderRadius(20);
                        Row.backgroundColor({ "id": 16777262, "type": 10001, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" });
                    }, Row);
                    Row.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.voiceStatus === VoiceStatusEnum.Transfer) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create();
                        Row.debugLine("entry/src/main/ets/components/VoiceInputs.ets(34:7)", "entry");
                        Row.width(280);
                        Row.height(120);
                        Row.borderRadius(20);
                        Row.backgroundColor({ "id": 16777262, "type": 10001, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" });
                    }, Row);
                    Row.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create({ alignContent: Alignment.Bottom });
            Stack.debugLine("entry/src/main/ets/components/VoiceInputs.ets(45:5)", "entry");
            Stack.height('100%');
            Stack.backgroundColor({ "id": 16777273, "type": 10001, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" });
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/components/VoiceInputs.ets(46:7)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.justifyContent(FlexAlign.Center);
            Column.alignItems(this.voiceStatus === VoiceStatusEnum.Cancel ? HorizontalAlign.Start : HorizontalAlign.Center);
        }, Column);
        this.getDisplayContent.bind(this)() //根据不同的状态显示内容
        ;
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //底部内容
            Column.create();
            Column.debugLine("entry/src/main/ets/components/VoiceInputs.ets(55:7)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //显示关闭和文本
            Row.create();
            Row.debugLine("entry/src/main/ets/components/VoiceInputs.ets(57:9)", "entry");
            //显示关闭和文本
            Row.width('100%');
            //显示关闭和文本
            Row.justifyContent(FlexAlign.SpaceBetween);
            //显示关闭和文本
            Row.padding({
                left: 40,
                right: 40
            });
            //显示关闭和文本
            Row.margin({
                bottom: 30
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/components/VoiceInputs.ets(58:11)", "entry");
            Row.width(70);
            Row.height(70);
            Row.borderRadius(35);
            Row.justifyContent(FlexAlign.Center);
            Row.backgroundColor(this.voiceStatus === VoiceStatusEnum.Cancel ? { "id": 16777260, "type": 10001, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" } : { "id": 16777274, "type": 10001, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" });
            Row.rotate({
                angle: -10
            });
            Row.scale({
                x: this.voiceStatus === VoiceStatusEnum.Cancel ? 1.2 : 1,
                y: this.voiceStatus === VoiceStatusEnum.Cancel ? 1.2 : 1
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777240, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/components/VoiceInputs.ets(59:13)", "entry");
            Image.width(30);
            Image.height(30);
            Image.fillColor(this.voiceStatus === VoiceStatusEnum.Cancel ? { "id": 16777271, "type": 10001, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" } : { "id": 16777275, "type": 10001, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" });
        }, Image);
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/components/VoiceInputs.ets(77:11)", "entry");
            Row.backgroundColor(this.voiceStatus === VoiceStatusEnum.Transfer ? { "id": 16777260, "type": 10001, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" } : { "id": 16777274, "type": 10001, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" });
            Row.width(70);
            Row.height(70);
            Row.borderRadius(35);
            Row.justifyContent(FlexAlign.Center);
            Row.rotate({
                angle: 10
            });
            Row.scale({
                x: this.voiceStatus === VoiceStatusEnum.Transfer ? 1.2 : 1,
                y: this.voiceStatus === VoiceStatusEnum.Transfer ? 1.2 : 1
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('文');
            Text.debugLine("entry/src/main/ets/components/VoiceInputs.ets(78:13)", "entry");
            Text.fontSize(24);
            Text.textAlign(TextAlign.Center);
            Text.fontColor(this.voiceStatus === VoiceStatusEnum.Transfer ? { "id": 16777271, "type": 10001, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" } : { "id": 16777275, "type": 10001, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" });
        }, Text);
        Text.pop();
        Row.pop();
        //显示关闭和文本
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create();
            Stack.debugLine("entry/src/main/ets/components/VoiceInputs.ets(106:9)", "entry");
            Stack.width('100%');
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777229, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/components/VoiceInputs.ets(107:11)", "entry");
            Image.width('100%');
            Image.height(120);
            Image.fillColor(this.voiceStatus === VoiceStatusEnum.Recording ? { "id": 16777260, "type": 10001, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" } : { "id": 16777260, "type": 10001, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" });
            Image.scale({
                x: 1.2
            });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777296, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/components/VoiceInputs.ets(114:11)", "entry");
            Image.width(30);
            Image.height(30);
            Image.fillColor(this.voiceStatus === VoiceStatusEnum.Recording ? { "id": 16777261, "type": 10001, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" } : { "id": 16777261, "type": 10001, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" });
        }, Image);
        Stack.pop();
        //底部内容
        Column.pop();
        Stack.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
export default VoiceInputs;
