if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface BottomInputs_Params {
    isText?: boolean;
    textContent?: string;
    showVoiceComponent?: boolean;
    //发送用户的文本消息，空函数。让父组件传过来
    submitTextMessage?: (content: string) => void;
    //发送用户的语音消息 空函数 让父组件传过来
    submitAudioMessage?: (msg: MessageModel) => void;
    showBottomCard?: boolean;
    bottomList?: PopupMenu[];
    screenWidth?: number;
    screenHeight?: number;
    voiceStatus?: VoiceStatusEnum;
    //定义发送图片消息的函数，由父组件传入的
    sendImageMessage?: (messageList: MessageModel[]) => void;
    connectUser?: UserModel //当前联系人，由父组件传过来
    ;
    currentUser?: UserModel //当前用户，由父组件传过来
    ;
    audioFilePath?: string;
    //定时器代码
    duration?: number;
    timer?: number;
}
import VoiceInputs from "@normalized:N&&&entry/src/main/ets/components/VoiceInputs&";
import display from "@ohos:display";
import promptAction from "@ohos:promptAction";
import { VoiceStatusEnum } from "@normalized:N&&&entry/src/main/ets/models/voiceEnum&";
import abilityAccessCtrl from "@ohos:abilityAccessCtrl";
import bundleManager from "@ohos:bundle.bundleManager";
import type common from "@ohos:app.ability.common";
import { init, initFile, release, start, stop } from "@normalized:N&&&entry/src/main/ets/utils/AudioRecordUtils&";
import type { UserModel } from '../models/users';
import { FileUtils } from "@normalized:N&&&entry/src/main/ets/utils/FileUtils&";
import { MessageModel, MessageTypeEnum } from "@normalized:N&&&entry/src/main/ets/models/msg&";
import type { MessageInterface } from "@normalized:N&&&entry/src/main/ets/models/msg&";
import { PopupMenu } from "@normalized:N&&&entry/src/main/ets/models/PopupMenu&";
import photoAccessHelper from "@ohos:file.photoAccessHelper";
import fileIo from "@ohos:file.fs";
import fileIO from "@ohos:fileio";
import camera from "@ohos:multimedia.camera";
import cameraPicker from "@ohos:multimedia.cameraPicker";
class BottomInputs extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__isText = new ObservedPropertySimplePU(true, this, "isText");
        this.__textContent = new ObservedPropertySimplePU('' //用户输入的聊天内容
        , this, "textContent");
        this.__showVoiceComponent = new ObservedPropertySimplePU(false //控制是否显示语音输入的视图组件
        //发送用户的文本消息，空函数。让父组件传过来
        , this, "showVoiceComponent");
        this.submitTextMessage = () => { };
        this.submitAudioMessage = () => { };
        this.__showBottomCard = new ObservedPropertySimplePU(false // 控制是否 显示底部 菜单列表
        , this, "showBottomCard");
        this.__bottomList = new ObservedPropertyObjectPU([
            new PopupMenu('照片', { "id": 16777294, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" }, () => { this.sendPhoto(); }),
            new PopupMenu('拍摄', { "id": 16777222, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" }, () => { this.openCameraAndSendImage(); }),
            new PopupMenu('位置', { "id": 16777245, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" }, () => { }),
            new PopupMenu('语音输入', { "id": 16777223, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" }, () => { }),
            new PopupMenu('收藏', { "id": 16777286, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" }, () => { }),
            new PopupMenu('个人名片', { "id": 16777248, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" }, () => { }),
            new PopupMenu('文件', { "id": 16777218, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" }, () => { }),
            new PopupMenu('音乐', { "id": 16777244, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" }, () => { })
        ], this, "bottomList");
        this.screenWidth = 0;
        this.screenHeight = 0;
        this.__voiceStatus = new ObservedPropertySimplePU(VoiceStatusEnum.Recording, this, "voiceStatus");
        this.addProvidedVar("voiceStatus", this.__voiceStatus, false);
        this.sendImageMessage = () => { };
        this.__connectUser = new SynchedPropertyObjectOneWayPU(params.connectUser, this, "connectUser");
        this.__currentUser = new SynchedPropertyObjectOneWayPU(params.currentUser, this, "currentUser");
        this.audioFilePath = '' //当前音频文件的路径
        ;
        this.duration = 0 //秒： 录音的时长
        ;
        this.timer = -1 //定时器的编号
        ;
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: BottomInputs_Params) {
        if (params.isText !== undefined) {
            this.isText = params.isText;
        }
        if (params.textContent !== undefined) {
            this.textContent = params.textContent;
        }
        if (params.showVoiceComponent !== undefined) {
            this.showVoiceComponent = params.showVoiceComponent;
        }
        if (params.submitTextMessage !== undefined) {
            this.submitTextMessage = params.submitTextMessage;
        }
        if (params.submitAudioMessage !== undefined) {
            this.submitAudioMessage = params.submitAudioMessage;
        }
        if (params.showBottomCard !== undefined) {
            this.showBottomCard = params.showBottomCard;
        }
        if (params.bottomList !== undefined) {
            this.bottomList = params.bottomList;
        }
        if (params.screenWidth !== undefined) {
            this.screenWidth = params.screenWidth;
        }
        if (params.screenHeight !== undefined) {
            this.screenHeight = params.screenHeight;
        }
        if (params.voiceStatus !== undefined) {
            this.voiceStatus = params.voiceStatus;
        }
        if (params.sendImageMessage !== undefined) {
            this.sendImageMessage = params.sendImageMessage;
        }
        if (params.audioFilePath !== undefined) {
            this.audioFilePath = params.audioFilePath;
        }
        if (params.duration !== undefined) {
            this.duration = params.duration;
        }
        if (params.timer !== undefined) {
            this.timer = params.timer;
        }
    }
    updateStateVars(params: BottomInputs_Params) {
        this.__connectUser.reset(params.connectUser);
        this.__currentUser.reset(params.currentUser);
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__isText.purgeDependencyOnElmtId(rmElmtId);
        this.__textContent.purgeDependencyOnElmtId(rmElmtId);
        this.__showVoiceComponent.purgeDependencyOnElmtId(rmElmtId);
        this.__showBottomCard.purgeDependencyOnElmtId(rmElmtId);
        this.__bottomList.purgeDependencyOnElmtId(rmElmtId);
        this.__voiceStatus.purgeDependencyOnElmtId(rmElmtId);
        this.__connectUser.purgeDependencyOnElmtId(rmElmtId);
        this.__currentUser.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__isText.aboutToBeDeleted();
        this.__textContent.aboutToBeDeleted();
        this.__showVoiceComponent.aboutToBeDeleted();
        this.__showBottomCard.aboutToBeDeleted();
        this.__bottomList.aboutToBeDeleted();
        this.__voiceStatus.aboutToBeDeleted();
        this.__connectUser.aboutToBeDeleted();
        this.__currentUser.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __isText: ObservedPropertySimplePU<boolean>;
    get isText() {
        return this.__isText.get();
    }
    set isText(newValue: boolean) {
        this.__isText.set(newValue);
    }
    private __textContent: ObservedPropertySimplePU<string>; //用户输入的聊天内容
    get textContent() {
        return this.__textContent.get();
    }
    set textContent(newValue: string) {
        this.__textContent.set(newValue);
    }
    private __showVoiceComponent: ObservedPropertySimplePU<boolean>; //控制是否显示语音输入的视图组件
    get showVoiceComponent() {
        return this.__showVoiceComponent.get();
    }
    set showVoiceComponent(newValue: boolean) {
        this.__showVoiceComponent.set(newValue);
    }
    //发送用户的文本消息，空函数。让父组件传过来
    private submitTextMessage: (content: string) => void;
    //发送用户的语音消息 空函数 让父组件传过来
    private submitAudioMessage: (msg: MessageModel) => void;
    private __showBottomCard: ObservedPropertySimplePU<boolean>; // 控制是否 显示底部 菜单列表
    get showBottomCard() {
        return this.__showBottomCard.get();
    }
    set showBottomCard(newValue: boolean) {
        this.__showBottomCard.set(newValue);
    }
    private __bottomList: ObservedPropertyObjectPU<PopupMenu[]>;
    get bottomList() {
        return this.__bottomList.get();
    }
    set bottomList(newValue: PopupMenu[]) {
        this.__bottomList.set(newValue);
    }
    private screenWidth: number;
    private screenHeight: number;
    private __voiceStatus: ObservedPropertySimplePU<VoiceStatusEnum>;
    get voiceStatus() {
        return this.__voiceStatus.get();
    }
    set voiceStatus(newValue: VoiceStatusEnum) {
        this.__voiceStatus.set(newValue);
    }
    aboutToAppear(): void {
        //计算整个屏幕的宽度和高度
        this.screenWidth = px2vp(display.getDefaultDisplaySync().width);
        this.screenHeight = px2vp(display.getDefaultDisplaySync().height);
        //初始化录制音频对象
        init();
    }
    //定义发送图片消息的函数，由父组件传入的
    private sendImageMessage: (messageList: MessageModel[]) => void;
    /**
     * 打开相机并且拍照，最后发送图片视频消息
     */
    async openCameraAndSendImage() {
        try {
            const pickerProfile: cameraPicker.PickerProfile = {
                cameraPosition: camera.CameraPosition.CAMERA_POSITION_BACK
            };
            //点击拍照，确认之后返回
            const result = await cameraPicker.pick(getContext(), [cameraPicker.PickerMediaType.PHOTO, cameraPicker.PickerMediaType.VIDEO], pickerProfile);
            // promptAction.showToast({ message: JSON.stringify(result) })
            if (result.resultUri !== '' && result.mediaType === 'photo') { //调用相机拍照
                const newFilePath = getContext().filesDir + '/' + Date.now() + '.jpg';
                //把用户选中的文件 拷贝到沙箱中
                const sourceFile = fileIo.openSync(result.resultUri, fileIo.OpenMode.READ_ONLY);
                fileIo.copyFileSync(sourceFile.fd, newFilePath);
                //每一张图片都是一个消息
                const imageMessage = new MessageModel({
                    sendUser: this.currentUser,
                    connectUser: this.connectUser,
                    messageContent: '[图片]',
                    messageType: MessageTypeEnum.IMAGE,
                    sourceFilePath: newFilePath
                } as MessageInterface);
                this.sendImageMessage([imageMessage]);
                fileIO.closeSync(sourceFile.fd);
            }
            else if (result.resultUri !== '' && result.mediaType === 'video') {
                const newFilePath = getContext().filesDir + '/' + Date.now() + '.mp4';
                //把用户选中的文件 拷贝到沙箱中
                const sourceFile = fileIo.openSync(result.resultUri, fileIo.OpenMode.READ_ONLY);
                fileIo.copyFileSync(sourceFile.fd, newFilePath);
                //录制的视频都是一个消息
                const imageMessage = new MessageModel({
                    sendUser: this.currentUser,
                    connectUser: this.connectUser,
                    messageContent: '[视频]',
                    messageType: MessageTypeEnum.VIDEO,
                    sourceFilePath: newFilePath
                } as MessageInterface);
                this.sendImageMessage([imageMessage]);
                fileIO.closeSync(sourceFile.fd);
            }
        }
        catch (err) {
            promptAction.showToast({ message: '相机打开失败' });
        }
    }
    /**
     * 发送到手机上的图片信息
     */
    async sendPhoto() {
        //初始化选择器对象
        let photoPicker = new photoAccessHelper.PhotoViewPicker();
        const result = await photoPicker.select({
            maxSelectNumber: 9,
            MIMEType: photoAccessHelper.PhotoViewMIMETypes.IMAGE_TYPE
        });
        if (result.photoUris.length > 0) {
            let imgList: MessageModel[] = []; //返回图片消息列表
            //拷贝到沙箱目录
            result.photoUris.forEach((item) => {
                const newFilePath = getContext().filesDir + '/' + Date.now() + '.jpg';
                //把用户选中的文件 拷贝到沙箱中
                const sourceFile = fileIo.openSync(item, fileIo.OpenMode.READ_ONLY);
                fileIo.copyFileSync(sourceFile.fd, newFilePath);
                //每一张图片都是一个消息
                const imageMessage = new MessageModel({
                    sendUser: this.currentUser,
                    connectUser: this.connectUser,
                    messageContent: '[图片]',
                    messageType: MessageTypeEnum.IMAGE,
                    sourceFilePath: newFilePath
                } as MessageInterface);
                imgList.push(imageMessage);
                fileIO.closeSync(sourceFile.fd);
            });
            this.sendImageMessage(imgList); //发送图片消息
            this.showBottomCard = false; //已经发送图片消息了，输入菜单不用显示了
        }
    }
    private __connectUser: SynchedPropertySimpleOneWayPU<UserModel>; //当前联系人，由父组件传过来
    get connectUser() {
        return this.__connectUser.get();
    }
    set connectUser(newValue: UserModel //当前联系人，由父组件传过来
    ) {
        this.__connectUser.set(newValue);
    }
    private __currentUser: SynchedPropertySimpleOneWayPU<UserModel>; //当前用户，由父组件传过来
    get currentUser() {
        return this.__currentUser.get();
    }
    set currentUser(newValue: UserModel //当前用户，由父组件传过来
    ) {
        this.__currentUser.set(newValue);
    }
    private audioFilePath: string; //当前音频文件的路径
    aboutToDisappear(): void {
        release();
    }
    //开始录音的函数
    beginAudio() {
        this.audioFilePath = initFile(this.connectUser.id); //创建音频文件
        start(); //开始录音的函数
        this.startTime(); //开始定时器
    }
    //结束录音
    endAudio() {
        stop();
        this.endTime(); //清空定时器
    }
    //释放手指之后处理的函数
    releaseFinger() {
        this.showVoiceComponent = false;
        this.endAudio(); //先关闭和停止录音
        if (this.voiceStatus === VoiceStatusEnum.Cancel) {
            //删除音频文件
            FileUtils.delFilePath(this.audioFilePath);
        }
        else if (this.voiceStatus === VoiceStatusEnum.Transfer) {
        }
        else if (this.voiceStatus === VoiceStatusEnum.Recording) {
            //如果是正常录制，并抬起手指，可以发送语音信息
            if (this.duration < 1) { //录音没有超过一秒
                promptAction.showToast({
                    message: '录音时长太短'
                });
                FileUtils.delFilePath(this.audioFilePath); //录音文件是垃圾文件 删除
                return;
            }
            //创建一条语音消息
            const msg = new MessageModel({
                sendUser: this.currentUser,
                connectUser: this.connectUser,
                messageContent: `[语音]${this.duration}`,
                messageType: MessageTypeEnum.AUDIO,
                sourceFilePath: this.audioFilePath,
                sourceDuration: this.duration
            } as MessageInterface);
            this.submitAudioMessage(msg);
            //清空变量
            this.audioFilePath = '';
        }
        //释放受之后，状态需要回复到初始值
        this.duration = 0; //录音时长恢复到0
        this.voiceStatus = VoiceStatusEnum.Recording;
    }
    //定时器代码
    private duration: number; //秒： 录音的时长
    private timer: number; //定时器的编号
    startTime() {
        this.timer = setInterval(() => {
            this.duration++;
            promptAction.showToast({ message: `当前语音：${this.duration}秒` });
        }, 1000);
    }
    endTime() {
        clearInterval(this.timer); //清除定时器
    }
    async checkMicroPhonePermission() {
        //检查是否有麦克风权限，没有则调整到系统设置中
        try {
            const manager = abilityAccessCtrl.createAtManager(); //创建权限控制管理器
            const bundleInfo = bundleManager.getBundleInfoForSelfSync(bundleManager.BundleFlag.GET_BUNDLE_INFO_WITH_APPLICATION);
            //检查是否有麦克风权限
            const status = manager.checkAccessTokenSync(bundleInfo.appInfo.accessTokenId, 'ohos.permission.MICROPHONE');
            if (status === abilityAccessCtrl.GrantStatus.PERMISSION_DENIED) { //没有麦克风权限
                //跳转到系统设置界面 打开新的UIAbility（系统设置的）
                const context = getContext() as common.UIAbilityContext;
                context.startAbility({
                    bundleName: 'com.huawei.hmos.settings',
                    abilityName: 'com.huawei.hmos.settings.MainAbility',
                    uri: 'application_info_entry',
                    parameters: {
                        pushParams: bundleInfo.name //从哪个包，弹出系统设置
                    }
                });
            }
            else {
                //有麦克风的权限
                this.showVoiceComponent = true;
                //调用录音的函数
                this.beginAudio();
            }
        }
        catch (err) {
            promptAction.showToast({ message: '麦克风未打开' });
        }
    }
    getVoiceComponent(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //builder中不饿能直接使用，自定义组件
            //解决办法：放到column里面就行
            Column.create();
            Column.debugLine("entry/src/main/ets/components/BottomInputs.ets(269:5)", "entry");
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new VoiceInputs(this, {}, undefined, elmtId, () => { }, { page: "entry/src/main/ets/components/BottomInputs.ets", line: 270, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {};
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
            }, { name: "VoiceInputs" });
        }
        //builder中不饿能直接使用，自定义组件
        //解决办法：放到column里面就行
        Column.pop();
    }
    getBottomMenuCard(item: PopupMenu, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/components/BottomInputs.ets(276:5)", "entry");
            Column.layoutWeight(1);
            Column.alignItems(HorizontalAlign.Center);
            Column.onClick(() => {
                item.itemClick && item.itemClick();
            });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/components/BottomInputs.ets(277:7)", "entry");
            Column.backgroundColor(Color.White);
            Column.width(56);
            Column.aspectRatio(1);
            Column.borderRadius(10);
            Column.justifyContent(FlexAlign.Center);
            Column.alignItems(HorizontalAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create(item.icon);
            Image.debugLine("entry/src/main/ets/components/BottomInputs.ets(278:9)", "entry");
            Image.width(30);
            Image.height(30);
            Image.fillColor('#4c4c4c');
        }, Image);
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.title);
            Text.debugLine("entry/src/main/ets/components/BottomInputs.ets(290:7)", "entry");
            Text.fontSize(12);
            Text.fontColor({ "id": 16777272, "type": 10001, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" });
            Text.margin({
                top: 10
            });
        }, Text);
        Text.pop();
        Column.pop();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/components/BottomInputs.ets(304:5)", "entry");
            Column.backgroundColor({ "id": 16777268, "type": 10001, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" });
            Column.bindContentCover({ value: this.showVoiceComponent, changeEvent: newValue => { this.showVoiceComponent = newValue; } }, { builder: () => {
                    this.getVoiceComponent.call(this);
                } }, {
                modalTransition: ModalTransition.DEFAULT //直接出现全屏的转成界面
            });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 10 });
            Row.debugLine("entry/src/main/ets/components/BottomInputs.ets(305:7)", "entry");
            Row.height(60);
            Row.width('100%');
            Row.padding({
                left: 10,
                right: 10
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create(this.isText ? { "id": 16777280, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" } : { "id": 16777221, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/components/BottomInputs.ets(306:9)", "entry");
            Image.width(25);
            Image.height(25);
            Image.onClick(() => {
                this.isText = !this.isText;
                if (!this.isText) {
                    // 调用 animateTo函数，弹出底部输入菜单，呈现出动画效果
                    Context.animateTo({ duration: 200 }, () => {
                        //弹出底部输入菜单
                        this.showBottomCard = false;
                    });
                }
            });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            //条件渲染
            if (this.isText) {
                this.ifElseBranchUpdateFunction(0, () => {
                    if (!If.canRetake('my_input')) {
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            TextInput.create({ text: { value: this.textContent, changeEvent: newValue => { this.textContent = newValue; } } });
                            TextInput.debugLine("entry/src/main/ets/components/BottomInputs.ets(322:11)", "entry");
                            TextInput.height(35);
                            TextInput.layoutWeight(1);
                            TextInput.borderRadius(2);
                            TextInput.backgroundColor(Color.White);
                            TextInput.focusable(true);
                            TextInput.defaultFocus(true);
                            TextInput.id('my_input');
                            TextInput.onSubmit(() => {
                                //输入文本并提交
                                this.submitTextMessage(this.textContent);
                                this.textContent = ''; //发送完后，设置为空
                                //继续让文本输入框 聚焦
                                focusControl.requestFocus('my_input');
                            });
                            TextInput.onClick(() => {
                                //调用animateTo函数  弹出底部输入菜单，呈现出动画效果
                                Context.animateTo({ duration: 200 }, () => {
                                    //弹出底部输入菜单
                                    this.showBottomCard = false;
                                });
                            });
                        }, TextInput);
                    }
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        //输入的是语音
                        Button.createWithLabel('长按说话', { type: ButtonType.Normal });
                        Button.debugLine("entry/src/main/ets/components/BottomInputs.ets(348:11)", "entry");
                        //输入的是语音
                        Button.backgroundColor(Color.White);
                        //输入的是语音
                        Button.layoutWeight(1);
                        //输入的是语音
                        Button.borderRadius(2);
                        //输入的是语音
                        Button.fontColor({ "id": 16777271, "type": 10001, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" });
                        Gesture.create(GesturePriority.Low);
                        GestureGroup.create(GestureMode.Parallel);
                        //长按手势
                        LongPressGesture.create();
                        //长按手势
                        LongPressGesture.onAction(() => {
                            //检查麦克风权限 并弹出语音输入的界面
                            this.checkMicroPhonePermission();
                        });
                        //长按手势
                        LongPressGesture.onActionEnd(() => {
                            this.releaseFinger();
                        });
                        //长按手势
                        LongPressGesture.pop();
                        //平移的手势
                        PanGesture.create();
                        //平移的手势
                        PanGesture.onActionUpdate((event) => {
                            // 判断手的坐标是否在取消范围内
                            if (event.fingerList[0].globalY > this.screenHeight - 120) { //判断手是不是再底部
                                //手一定在录音的区域
                                this.voiceStatus = VoiceStatusEnum.Recording;
                                // promptAction.showToast({message: 'Recording'})
                            }
                            else {
                                //手不再录音区，可能取消，可能转文字
                                if (event.fingerList[0].globalX < this.screenWidth / 2) {
                                    //手一定在取消区
                                    this.voiceStatus = VoiceStatusEnum.Cancel;
                                    // promptAction.showToast({message:'Cancel'})
                                }
                                else {
                                    this.voiceStatus = VoiceStatusEnum.Transfer;
                                    // promptAction.showToast({message:'Transfer'})
                                }
                            }
                        });
                        //平移的手势
                        PanGesture.onActionEnd(() => {
                            //又回到默认状态
                            this.voiceStatus = VoiceStatusEnum.Recording;
                        });
                        //平移的手势
                        PanGesture.pop();
                        GestureGroup.pop();
                        Gesture.pop();
                    }, Button);
                    //输入的是语音
                    Button.pop();
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777219, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/components/BottomInputs.ets(395:9)", "entry");
            Image.width(25);
            Image.height(25);
            Image.onClick(() => {
                //调用animateTo函数  弹出底部输入菜单，呈现出动画效果
                Context.animateTo({ duration: 200 }, () => {
                    //弹出底部输入菜单
                    this.showBottomCard = !this.showBottomCard;
                });
            });
        }, Image);
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            //渲染底部输入菜单，一共八个菜单，采用循环渲染的方式
            if (this.showBottomCard) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        GridRow.create({ columns: 4 });
                        GridRow.debugLine("entry/src/main/ets/components/BottomInputs.ets(416:9)", "entry");
                        GridRow.width('100%');
                    }, GridRow);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = _item => {
                            const item = _item;
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                GridCol.create();
                                GridCol.debugLine("entry/src/main/ets/components/BottomInputs.ets(418:13)", "entry");
                                GridCol.height(100);
                            }, GridCol);
                            //渲染单个菜单
                            this.getBottomMenuCard.bind(this)(item);
                            GridCol.pop();
                        };
                        this.forEachUpdateFunction(elmtId, this.bottomList, forEachItemGenFunction);
                    }, ForEach);
                    ForEach.pop();
                    GridRow.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
export default BottomInputs;
