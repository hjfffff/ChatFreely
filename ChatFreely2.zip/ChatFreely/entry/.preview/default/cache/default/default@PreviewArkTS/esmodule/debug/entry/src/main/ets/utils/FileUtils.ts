import fileIo from "@ohos:file.fs";
export class FileUtils {
    /**
     * 根据用户的ID，创建一个空白的音频文件。
     * 每个联系人用户对应一个目录，以便区分
     * 音频文件的后缀为：.wav
     * 音频文件的名字：采用当前时间戳 命名
     * @param userId
     * @returns 返回文件路径
     */
    static createAudioFile(userId: string) {
        // 判断有无路径,没有就创建
        let dirPath = getContext().filesDir + '/' + userId;
        let flag = fileIo.accessSync(dirPath);
        if (!flag) { // 如果目录不存在，则创建目录
            fileIo.mkdirSync(dirPath);
        }
        //每个用户的文件隔离，方便删除
        let filePath = dirPath + '/' + Date.now() + '.wav';
        //创建文件
        const file = fileIo.openSync(filePath, fileIo.OpenMode.CREATE);
        fileIo.closeSync(file);
        return filePath; // 返回文件路径
    }
    /**
     * 根据文件路径，删除某一个文件
     * @param filePath
     */
    static delFilePath(filePath: string) {
        if (filePath) {
            fileIo.unlinkSync(filePath);
        }
    }
    /**
     * 根据一个用户ID，删除该用户目录下的所有音频文件
     * @param userId
     */
    static delUserPath(userId: string) {
        if (userId) {
            let dirPath = getContext().filesDir + '/' + userId;
            let flag = fileIo.accessSync(dirPath);
            if (flag) {
                fileIo.rmdirSync(dirPath);
            }
        }
    }
}
