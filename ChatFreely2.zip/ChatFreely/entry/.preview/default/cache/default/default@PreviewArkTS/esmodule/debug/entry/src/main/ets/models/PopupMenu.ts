export class PopupMenu {
    title: string = '';
    icon: ResourceStr = '';
    itemClick?: () => void;
    constructor(title: string, icon: ResourceStr, itemClick?: () => void) {
        this.title = title;
        this.icon = icon;
        this.itemClick = itemClick;
    }
}
