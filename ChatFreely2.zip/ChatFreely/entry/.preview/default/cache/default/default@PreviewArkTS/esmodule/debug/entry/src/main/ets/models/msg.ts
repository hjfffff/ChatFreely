import type { UserModel } from './users';
import util from "@ohos:util";
export enum MessageTypeEnum {
    TEXT = // 文本
     0,
    IMAGE = // 图片
     1,
    AUDIO = // 音频
     2,
    VIDEO = // 视频
     3,
    LOCATION = // 定位
     4,
    LINK = 5 // 链接
}
export interface MessageInterface {
    id: string;
    sendUser: UserModel; //消息的发送用户
    connectUser: UserModel; // 联系人
    messageContent: string; //消息的内容
    sendTime: number; //发送时间戳
    messageType: MessageTypeEnum; //消息类型
    sourceFilePath: string; //资源文件的沙箱地址，存储地址
    sourceDuration: number; //资源时长，视频和音频资源有时长
}
export class MessageModel implements MessageInterface {
    id: string;
    sendUser: UserModel; //消息的发送用户
    connectUser: UserModel; // 联系人
    messageContent: string; //消息的内容
    sendTime: number; //发送时间戳 1970.1.1
    messageType: MessageTypeEnum; //消息类型
    sourceFilePath: string; //资源文件的沙箱地址，存储地址
    sourceDuration: number; //资源时长，视频和音频资源有时长
    constructor(model: MessageInterface) {
        this.id = model.id || util.generateRandomUUID(); // 如果没有id，则自动生成一个随机的ID
        this.sendUser = model.sendUser;
        this.connectUser = model.connectUser;
        this.messageContent = model.messageContent;
        this.sendTime = model.sendTime || Date.now(); // 没有时间，则用当前系统时间戳
        this.messageType = model.messageType || MessageTypeEnum.TEXT; // 默认是文本消息类型
        this.sourceFilePath = model.sourceFilePath;
        this.sourceDuration = model.sourceDuration;
    }
}
