if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface ConnectUser_Params {
    userList?: UserModel[];
    filterList?: UserModel[];
    searchText?: string;
}
import { UserModel } from "@normalized:N&&&entry/src/main/ets/models/users&";
import router from "@ohos:router";
class ConnectUser extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__userList = new ObservedPropertyObjectPU(UserModel.initData() //当前界面需要用到的联系人列表数据
        // @State filterList: UserModel[] = UserModel.initData()
        , this, "userList");
        this.__filterList = new ObservedPropertyObjectPU(this.userList //搜索过滤之后的联系人列表
        , this, "filterList");
        this.__searchText = new ObservedPropertySimplePU('' //用户输入的搜索关键字
        , this, "searchText");
        this.setInitiallyProvidedValue(params);
        this.declareWatch("searchText", this.myFilter);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: ConnectUser_Params) {
        if (params.userList !== undefined) {
            this.userList = params.userList;
        }
        if (params.filterList !== undefined) {
            this.filterList = params.filterList;
        }
        if (params.searchText !== undefined) {
            this.searchText = params.searchText;
        }
    }
    updateStateVars(params: ConnectUser_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__userList.purgeDependencyOnElmtId(rmElmtId);
        this.__filterList.purgeDependencyOnElmtId(rmElmtId);
        this.__searchText.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__userList.aboutToBeDeleted();
        this.__filterList.aboutToBeDeleted();
        this.__searchText.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __userList: ObservedPropertyObjectPU<UserModel[]>; //当前界面需要用到的联系人列表数据
    get userList() {
        return this.__userList.get();
    }
    set userList(newValue: UserModel[]) {
        this.__userList.set(newValue);
    }
    // @State filterList: UserModel[] = UserModel.initData()
    private __filterList: ObservedPropertyObjectPU<UserModel[]>; //搜索过滤之后的联系人列表
    get filterList() {
        return this.__filterList.get();
    }
    set filterList(newValue: UserModel[]) {
        this.__filterList.set(newValue);
    }
    private __searchText: ObservedPropertySimplePU<string>; //用户输入的搜索关键字
    get searchText() {
        return this.__searchText.get();
    }
    set searchText(newValue: string) {
        this.__searchText.set(newValue);
    }
    myFilter() {
        this.filterList = this.userList.filter((user: UserModel) => {
            return user.username.includes(this.searchText);
        });
    }
    //定义一个子组件，展示联系人标签页的内容
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/components/ConnectUser.ets(24:5)", "entry");
            Column.height('100%');
            Column.padding({
                top: 20
            });
            Column.backgroundColor({ "id": 16777257, "type": 10001, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/components/ConnectUser.ets(25:7)", "entry");
            Row.width('100%');
            Row.padding({
                left: 10,
                right: 10
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Search.create({ placeholder: '搜索联系人', value: { value: this.searchText, changeEvent: newValue => { this.searchText = newValue; } } });
            Search.debugLine("entry/src/main/ets/components/ConnectUser.ets(26:9)", "entry");
            Search.height(30);
            Search.backgroundColor({ "id": 16777276, "type": 10001, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" });
            Search.borderRadius(4);
        }, Search);
        Search.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //第一行：搜索框 结束
            List.create();
            List.debugLine("entry/src/main/ets/components/ConnectUser.ets(37:7)", "entry");
            //第一行：搜索框 结束
            List.backgroundColor(Color.White);
            //第一行：搜索框 结束
            List.padding({
                top: 10,
                bottom: 10
            });
            //第一行：搜索框 结束
            List.divider({
                strokeWidth: 1,
                color: { "id": 16777259, "type": 10001, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" }
            });
        }, List);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                {
                    const itemCreation = (elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        itemCreation2(elmtId, isInitialRender);
                        if (!isInitialRender) {
                            //每一个item就是一个联系人用户
                            ListItem.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    };
                    const itemCreation2 = (elmtId, isInitialRender) => {
                        ListItem.create(deepRenderFunction, true);
                        //每一个item就是一个联系人用户
                        ListItem.onClick(() => {
                            router.pushUrl({
                                url: 'pages/chat/Chat',
                                params: item //数据
                            });
                        });
                        ListItem.debugLine("entry/src/main/ets/components/ConnectUser.ets(40:11)", "entry");
                    };
                    const deepRenderFunction = (elmtId, isInitialRender) => {
                        itemCreation(elmtId, isInitialRender);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Row.create({ space: 10 });
                            Row.debugLine("entry/src/main/ets/components/ConnectUser.ets(41:13)", "entry");
                            Row.width('100%');
                            Row.height(60);
                            Row.padding({ left: 10, right: 10 });
                            ViewStackProcessor.visualState("pressed");
                            Row.backgroundColor({ "id": 16777257, "type": 10001, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" });
                            ViewStackProcessor.visualState("normal");
                            Row.backgroundColor({ "id": 16777276, "type": 10001, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" });
                            ViewStackProcessor.visualState();
                        }, Row);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Image.create(item.avatar);
                            Image.debugLine("entry/src/main/ets/components/ConnectUser.ets(42:15)", "entry");
                            Image.width(30);
                            Image.height(30);
                            Image.borderRadius(4);
                        }, Image);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Column.create();
                            Column.debugLine("entry/src/main/ets/components/ConnectUser.ets(46:15)", "entry");
                            Column.layoutWeight(1);
                            Column.alignItems(HorizontalAlign.Start);
                            Column.justifyContent(FlexAlign.Center);
                        }, Column);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Text.create(item.username);
                            Text.debugLine("entry/src/main/ets/components/ConnectUser.ets(47:17)", "entry");
                            Text.fontColor({ "id": 16777271, "type": 10001, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" });
                            Text.fontSize(14);
                        }, Text);
                        Text.pop();
                        Column.pop();
                        Row.pop();
                        //每一个item就是一个联系人用户
                        ListItem.pop();
                    };
                    this.observeComponentCreation2(itemCreation2, ListItem);
                    //每一个item就是一个联系人用户
                    ListItem.pop();
                }
            };
            this.forEachUpdateFunction(elmtId, this.filterList, forEachItemGenFunction);
        }, ForEach);
        ForEach.pop();
        //第一行：搜索框 结束
        List.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
export default ConnectUser;
