if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface FxComp_Params {
}
interface Page_Params {
    FiList?: FindList[];
}
import { FindList } from "@normalized:N&&&entry/src/main/ets/models/find&";
class Page extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__FiList = new ObservedPropertyObjectPU(FindList.FiList(), this, "FiList");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Page_Params) {
        if (params.FiList !== undefined) {
            this.FiList = params.FiList;
        }
    }
    updateStateVars(params: Page_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__FiList.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__FiList.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __FiList: ObservedPropertyObjectPU<FindList[]>;
    get FiList() {
        return this.__FiList.get();
    }
    set FiList(newValue: FindList[]) {
        this.__FiList.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/chat/Page.ets(10:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor('#e6e6e6');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create();
            Stack.debugLine("entry/src/main/ets/pages/chat/Page.ets(11:7)", "entry");
            Stack.backgroundColor('#e6e6e6');
            Stack.width('100%');
            Stack.height(50);
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('发现');
            Text.debugLine("entry/src/main/ets/pages/chat/Page.ets(12:9)", "entry");
            Text.fontSize(18);
            Text.fontWeight(FontWeight.Bold);
        }, Text);
        Text.pop();
        Stack.pop();
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new FxComp(this, {}, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/chat/Page.ets", line: 20, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {};
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
            }, { name: "FxComp" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Divider.create();
            Divider.debugLine("entry/src/main/ets/pages/chat/Page.ets(22:7)", "entry");
            Divider.strokeWidth(9);
            Divider.backgroundColor('#e6e6e6');
            Divider.opacity(0.3);
        }, Divider);
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Page";
    }
}
export class FxComp extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: FxComp_Params) {
    }
    updateStateVars(params: FxComp_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/chat/Page.ets(42:5)", "entry");
            Row.backgroundColor(Color.White);
            Row.padding(15);
            Row.width('100%');
            Row.justifyContent(FlexAlign.SpaceBetween);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 10 });
            Row.debugLine("entry/src/main/ets/pages/chat/Page.ets(43:7)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777314, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/chat/Page.ets(44:9)", "entry");
            Image.aspectRatio(1);
            Image.width(30);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('朋友圈');
            Text.debugLine("entry/src/main/ets/pages/chat/Page.ets(47:9)", "entry");
            Text.fontSize(17);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777281, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/chat/Page.ets(51:7)", "entry");
            Image.width(15);
        }, Image);
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
registerNamedRoute(() => new Page(undefined, {}), "", { bundleName: "com.hjf.chatfreely", moduleName: "entry", pagePath: "pages/chat/Page", pageFullPath: "entry/src/main/ets/pages/chat/Page", integratedHsp: "false" });
