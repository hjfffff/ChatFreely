import abilityAccessCtrl from "@ohos:abilityAccessCtrl";
import UIAbility from "@ohos:app.ability.UIAbility";
import type AbilityConstant from "@ohos:app.ability.AbilityConstant";
import type Want from "@ohos:app.ability.Want";
import hilog from "@ohos:hilog";
import type { KeyboardAvoidMode } from "@ohos:arkui.UIContext";
import type window from "@ohos:window";
import { AppStorageUtils } from "@normalized:N&&&entry/src/main/ets/utils/AppStorageUtils&";
export default class EntryAbility extends UIAbility {
    async onCreate(want: Want, launchParam: AbilityConstant.LaunchParam): Promise<void> {
        hilog.info(0x0000, 'testTag', '%{public}s', 'Ability onCreate');
        //弹出申请麦克风的权限
        const manager = abilityAccessCtrl.createAtManager(); //创建权限控制管理器
        await manager.requestPermissionsFromUser(this.context, [
            'ohos.permission.MICROPHONE'
        ]);
    }
    onDestroy(): void {
        hilog.info(0x0000, 'testTag', '%{public}s', 'Ability onDestroy');
    }
    onWindowStageCreate(windowStage: window.WindowStage): void {
        // Main window is created, set main page for this ability
        hilog.info(0x0000, 'testTag', '%{public}s', 'Ability onWindowStageCreate');
        windowStage.loadContent('pages/Index', (err) => {
            if (err.code) {
                hilog.error(0x0000, 'testTag', 'Failed to load the content. Cause: %{public}s', JSON.stringify(err) ?? '');
                return;
            }
            AppStorageUtils.init(this.context); //一个UIAbility有一个统一的上下文对象context
            // 设置避让模式
            windowStage.getMainWindowSync().getUIContext().setKeyboardAvoidMode(1);
            hilog.info(0x0000, 'testTag', 'Succeeded in loading the content.');
        });
    }
    onWindowStageDestroy(): void {
        // Main window is destroyed, release UI related resources
        hilog.info(0x0000, 'testTag', '%{public}s', 'Ability onWindowStageDestroy');
    }
    onForeground(): void {
        // Ability has brought to foreground
        hilog.info(0x0000, 'testTag', '%{public}s', 'Ability onForeground');
    }
    onBackground(): void {
        // Ability has back to background
        hilog.info(0x0000, 'testTag', '%{public}s', 'Ability onBackground');
    }
}
