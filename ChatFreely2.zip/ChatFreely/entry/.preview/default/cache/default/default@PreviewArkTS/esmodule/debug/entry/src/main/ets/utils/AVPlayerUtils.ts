import media from "@ohos:multimedia.media";
export class AVPlayerUtils {
    //播放器
    static player: media.AVPlayer;
    static context: Context;
    //初始化:
    static async init(context: Context) {
        // 1.创建播放器:状态->idle
        AVPlayerUtils.player = await media.createAVPlayer();
        AVPlayerUtils.context = context;
        // 1.监控状态，并设置回调函数
        AVPlayerUtils.player.on('stateChange', async (state) => {
            if (state === 'initialized') {
                // 状态:prepared
                AVPlayerUtils.player.prepare();
            }
            else if (state === 'prepared') {
                // 状态:playing
                AVPlayerUtils.player.play();
            }
            else if (state === 'completed') {
                //   播放完成：
                await AVPlayerUtils.player.reset();
            }
        });
        // error回调监听函数,当avPlayer在操作过程中出现错误时调用 reset接口触发重置流程
        AVPlayerUtils.player.on('error', async (err) => {
            console.error(`Invoke avPlayer failed, code is ${err.code}, message is ${err.message}`);
            await AVPlayerUtils.player.reset(); // 调用reset重置资源，触发idle状态
        });
        AVPlayerUtils.player.on('durationUpdate', (duration) => {
            //  duration是 当前设置资源的时长
        });
        AVPlayerUtils.player.on('timeUpdate', (time) => {
            //  time是 当前播放的时长（高频率更新）
        });
        AVPlayerUtils.player.on('seekDone', (seekTime) => {
            //   监听切换播放进度事件
            //   seekTime是要切换的时长
        });
    }
    // 2.设置音频源
    /**
     * 通过传参，来播放指定的提示声音
     * @param type  'camera'（拍照） | 'information'（收到信息） | 'send'（发送）
     */
    static async play(type: 'camera' | 'information' | 'send') {
        // 只有idle才能设置src -> idle
        await AVPlayerUtils.player.reset();
        // 在线文件播放：
        // AVPlayerUtils.player.url = 'https://m804.music.126.net/20240605194838/cb0df5c12374e576e7a8b1b3352f1679/jdyyaac/obj/w5rDlsOJwrLDjj7CmsOj/7259260757/955f/81fe/bd0f/3d71ae535cbc6e99a91099f1104e80f3.m4a?authSecret=0000018fe823e89c1c000aaba04a67a4'
        // 本地文件播放：
        // 状态：initialized
        let fileDescriptor = AVPlayerUtils.context.resourceManager.getRawFdSync(type + '.wav');
        AVPlayerUtils.player.fdSrc = fileDescriptor;
    }
}
