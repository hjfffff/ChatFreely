if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Chat_Params {
    token?: string;
    connectUser?: UserModel;
    currentUser?: UserModel;
    messageList?: MessageModel[];
    otherInputIngFlag?: boolean;
    scroller?: Scroller;
    previewType?: MessageTypeEnum;
    previewUrl?: ResourceStr;
    previewController?: CustomDialogController;
}
import router from "@ohos:router";
import BottomInputs from "@normalized:N&&&entry/src/main/ets/components/BottomInputs&";
import MessageDetail from "@normalized:N&&&entry/src/main/ets/components/MessageDetail&";
import PreviewImage from "@normalized:N&&&entry/src/main/ets/components/PreviewImage&";
import { ReqMessage } from "@normalized:N&&&entry/src/main/ets/models/ai&";
import type { RespMessage } from "@normalized:N&&&entry/src/main/ets/models/ai&";
import { MessageModel, MessageTypeEnum } from "@normalized:N&&&entry/src/main/ets/models/msg&";
import type { MessageInterface } from "@normalized:N&&&entry/src/main/ets/models/msg&";
import { UserModel } from "@normalized:N&&&entry/src/main/ets/models/users&";
import { AppStorageUtils } from "@normalized:N&&&entry/src/main/ets/utils/AppStorageUtils&";
import { AudioRenderUtils } from "@normalized:N&&&entry/src/main/ets/utils/AudioRenderUtils&";
import { AVPlayerUtils } from "@normalized:N&&&entry/src/main/ets/utils/AVPlayerUtils&";
import { requestMessage } from "@normalized:N&&&entry/src/main/ets/utils/request&";
class Chat extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__token = this.createStorageProp(AppStorageUtils.TOKEN_KEY1, '', "token");
        this.__connectUser = new ObservedPropertyObjectPU(new UserModel() //代表当前聊天的联系人
        , this, "connectUser");
        this.currentUser = UserModel.getCurrentUser() //代表当前聊天的联系人
        ;
        this.__messageList = new ObservedPropertyObjectPU([] //存放所有聊天消息的列表
        , this, "messageList");
        this.__otherInputIngFlag = new ObservedPropertySimplePU(false //控制是否显示：正在输入...
        , this, "otherInputIngFlag");
        this.scroller = new Scroller();
        this.previewType = MessageTypeEnum.IMAGE;
        this.previewUrl = '';
        this.previewController = new CustomDialogController({
            builder: () => {
                let jsDialog = new PreviewImage(this, {
                    url: this.previewUrl,
                    type: this.previewType,
                }, undefined, -1, () => { }, { page: "entry/src/main/ets/pages/chat/Chat.ets", line: 30, col: 14 });
                jsDialog.setController(this.previewController);
                ViewPU.create(jsDialog);
                let paramsLambda = () => {
                    return {
                        url: this.previewUrl,
                        type: this.previewType
                    };
                };
                jsDialog.paramsGenerator_ = paramsLambda;
            },
            autoCancel: false,
            customStyle: true
        }, this);
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Chat_Params) {
        if (params.connectUser !== undefined) {
            this.connectUser = params.connectUser;
        }
        if (params.currentUser !== undefined) {
            this.currentUser = params.currentUser;
        }
        if (params.messageList !== undefined) {
            this.messageList = params.messageList;
        }
        if (params.otherInputIngFlag !== undefined) {
            this.otherInputIngFlag = params.otherInputIngFlag;
        }
        if (params.scroller !== undefined) {
            this.scroller = params.scroller;
        }
        if (params.previewType !== undefined) {
            this.previewType = params.previewType;
        }
        if (params.previewUrl !== undefined) {
            this.previewUrl = params.previewUrl;
        }
        if (params.previewController !== undefined) {
            this.previewController = params.previewController;
        }
    }
    updateStateVars(params: Chat_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__token.purgeDependencyOnElmtId(rmElmtId);
        this.__connectUser.purgeDependencyOnElmtId(rmElmtId);
        this.__messageList.purgeDependencyOnElmtId(rmElmtId);
        this.__otherInputIngFlag.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__token.aboutToBeDeleted();
        this.__connectUser.aboutToBeDeleted();
        this.__messageList.aboutToBeDeleted();
        this.__otherInputIngFlag.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __token: ObservedPropertyAbstractPU<string>;
    get token() {
        return this.__token.get();
    }
    set token(newValue: string) {
        this.__token.set(newValue);
    }
    private __connectUser: ObservedPropertyObjectPU<UserModel>; //代表当前聊天的联系人
    get connectUser() {
        return this.__connectUser.get();
    }
    set connectUser(newValue: UserModel) {
        this.__connectUser.set(newValue);
    }
    private currentUser: UserModel; //代表当前聊天的联系人
    private __messageList: ObservedPropertyObjectPU<MessageModel[]>; //存放所有聊天消息的列表
    get messageList() {
        return this.__messageList.get();
    }
    set messageList(newValue: MessageModel[]) {
        this.__messageList.set(newValue);
    }
    private __otherInputIngFlag: ObservedPropertySimplePU<boolean>; //控制是否显示：正在输入...
    get otherInputIngFlag() {
        return this.__otherInputIngFlag.get();
    }
    set otherInputIngFlag(newValue: boolean) {
        this.__otherInputIngFlag.set(newValue);
    }
    private scroller: Scroller;
    private previewType: MessageTypeEnum;
    private previewUrl: ResourceStr;
    private previewController: CustomDialogController;
    //删除一条消息的函数
    async deleteMessage(msgId: string) {
        let index = this.messageList.findIndex(msg => msg.id === msgId);
        await AppStorageUtils.removeChatMessage(this.connectUser.id, msgId);
        this.messageList.splice(index, 1); //删除一条消息的函数
    }
    //用户 发送文本消息的函数，因为只有当前组件才能展示聊天消息
    async sendTextMessage(textContent: string) {
        let message = new MessageModel({
            //把用户发送的文本内容，封装成一个对象
            messageContent: textContent,
            sendUser: this.currentUser,
            connectUser: this.connectUser
        } as MessageInterface);
        //后面展示消息
        this.messageList.push(message); // 把当前用户发送的文本消息，添加到messageList。
        // 播放发送消息的提示声音
        AVPlayerUtils.play('send');
        await AppStorageUtils.addChatMessage(this.connectUser.id, message); //存储消息到首选项
        this.otherInputIngFlag = true;
        this.scroller.scrollEdge(Edge.Bottom); //只要发送一条文本消息自动滚到底部
        this.reqAIMessage(message.messageContent);
    }
    //用户 发送语音消息的函数，因为只有当前组件才能展示聊天消息
    async sendAudioMessage(message: MessageModel) {
        //后面展示消息
        this.messageList.push(message); //把当前用户发送的消息，添加到messageList
        AVPlayerUtils.play('send');
        await AppStorageUtils.addChatMessage(this.connectUser.id, message); //存储消息到首选项
        this.scroller.scrollEdge(Edge.Bottom); //只要发送一条文本消息自动滚到底部
    }
    //用户 发送语音消息的函数，因为只有当前组件才能展示聊天消息
    async sendImageMessage(list: MessageModel[]) {
        //后面展示消息
        this.messageList.push(...list); //把当前用户发送的消息，添加到messageList
        AVPlayerUtils.play('send');
        list.forEach(async (item) => {
            await AppStorageUtils.addChatMessage(this.connectUser.id, item); //存储消息到首选项
        });
        this.scroller.scrollEdge(Edge.Bottom); //只要发送一条文本消息自动滚到底部
    }
    async reqAIMessage(msg: string) {
        //用户的问题传过去
        const data = new ReqMessage('user', msg);
        const result: RespMessage = await requestMessage(data, this.token);
        //把ai返回的回答封装成一个message对象，并渲染出来
        let message: MessageModel = new MessageModel({
            messageContent: result.result,
            sendUser: this.connectUser,
            connectUser: this.connectUser
        } as MessageInterface);
        this.messageList.push(message);
        // 收到新的消息的时候，播放提示声音
        AVPlayerUtils.play('information');
        await AppStorageUtils.addChatMessage(this.connectUser.id, message); //存储消息到首选项
        this.scroller.scrollEdge(Edge.Bottom); //对方联系人回复了一条文本消息自动滚到底部
        //ai已经回答了，取消正在输入
        this.otherInputIngFlag = false;
    }
    aboutToAppear(): void {
        //接受参数 router.getParams()返回的是一个Object对象
        this.connectUser = router.getParams() as UserModel;
        //从首选项中获取当前联系人的所有聊天记录
        this.messageList = AppStorageUtils.getChatMessage(this.connectUser.id);
        //初始化播放器
        AudioRenderUtils.init();
    }
    aboutToDisappear(): void {
        AudioRenderUtils.release();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/chat/Chat.ets(122:5)", "entry");
            Column.height('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //界面的头部
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/chat/Chat.ets(124:7)", "entry");
            //界面的头部
            Row.padding({
                left: 10,
                right: 10
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create({ alignContent: Alignment.Start });
            Stack.debugLine("entry/src/main/ets/pages/chat/Chat.ets(125:9)", "entry");
            Stack.height(50);
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777247, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/chat/Chat.ets(126:11)", "entry");
            Image.width(30);
            Image.height(30);
            Image.onClick(() => {
                router.back(); //联系人界面来，返回到联系人界面
            });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.otherInputIngFlag ? '对方正在输入...' : this.connectUser.username);
            Text.debugLine("entry/src/main/ets/pages/chat/Chat.ets(133:11)", "entry");
            Text.width('100%');
            Text.textAlign(TextAlign.Center);
            Text.fontSize(16);
            Text.fontColor({ "id": 16777271, "type": 10001, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" });
        }, Text);
        Text.pop();
        Stack.pop();
        //界面的头部
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //界面中间： 展示聊天记录的列表
            List.create({ space: 10, scroller: this.scroller });
            List.debugLine("entry/src/main/ets/pages/chat/Chat.ets(147:7)", "entry");
            //界面中间： 展示聊天记录的列表
            List.layoutWeight(1);
            //界面中间： 展示聊天记录的列表
            List.width('100%');
            //界面中间： 展示聊天记录的列表
            List.padding({
                top: 20,
                bottom: 10
            });
            //界面中间： 展示聊天记录的列表
            List.backgroundColor({ "id": 16777257, "type": 10001, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" });
        }, List);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                {
                    const itemCreation = (elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        itemCreation2(elmtId, isInitialRender);
                        if (!isInitialRender) {
                            ListItem.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    };
                    const itemCreation2 = (elmtId, isInitialRender) => {
                        ListItem.create(deepRenderFunction, true);
                        ListItem.debugLine("entry/src/main/ets/pages/chat/Chat.ets(149:11)", "entry");
                    };
                    const deepRenderFunction = (elmtId, isInitialRender) => {
                        itemCreation(elmtId, isInitialRender);
                        {
                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                if (isInitialRender) {
                                    let componentCall = new MessageDetail(this, { item: item, delMessage: (msgId: string) => { this.deleteMessage(msgId); },
                                        previewMedia: () => {
                                            this.previewType = item.messageType;
                                            this.previewUrl = 'file://' + item.sourceFilePath;
                                            this.previewController.open(); //弹出弹窗
                                        }
                                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/chat/Chat.ets", line: 150, col: 13 });
                                    ViewPU.create(componentCall);
                                    let paramsLambda = () => {
                                        return {
                                            item: item,
                                            delMessage: (msgId: string) => { this.deleteMessage(msgId); },
                                            previewMedia: () => {
                                                this.previewType = item.messageType;
                                                this.previewUrl = 'file://' + item.sourceFilePath;
                                                this.previewController.open(); //弹出弹窗
                                            }
                                        };
                                    };
                                    componentCall.paramsGenerator_ = paramsLambda;
                                }
                                else {
                                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                                }
                            }, { name: "MessageDetail" });
                        }
                        ListItem.pop();
                    };
                    this.observeComponentCreation2(itemCreation2, ListItem);
                    ListItem.pop();
                }
            };
            this.forEachUpdateFunction(elmtId, this.messageList, forEachItemGenFunction);
        }, ForEach);
        ForEach.pop();
        //界面中间： 展示聊天记录的列表
        List.pop();
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new BottomInputs(this, {
                        connectUser: this.connectUser,
                        currentUser: this.currentUser,
                        submitTextMessage: (content: string) => {
                            this.sendTextMessage(content);
                        },
                        submitAudioMessage: (msg: MessageModel) => {
                            this.sendAudioMessage(msg);
                        },
                        sendImageMessage: (list: MessageModel[]) => {
                            this.sendImageMessage(list);
                        }
                    }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/chat/Chat.ets", line: 168, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            connectUser: this.connectUser,
                            currentUser: this.currentUser,
                            submitTextMessage: (content: string) => {
                                this.sendTextMessage(content);
                            },
                            submitAudioMessage: (msg: MessageModel) => {
                                this.sendAudioMessage(msg);
                            },
                            sendImageMessage: (list: MessageModel[]) => {
                                this.sendImageMessage(list);
                            }
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        connectUser: this.connectUser,
                        currentUser: this.currentUser
                    });
                }
            }, { name: "BottomInputs" });
        }
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Chat";
    }
}
registerNamedRoute(() => new Chat(undefined, {}), "", { bundleName: "com.hjf.chatfreely", moduleName: "entry", pagePath: "pages/chat/Chat", pageFullPath: "entry/src/main/ets/pages/chat/Chat", integratedHsp: "false" });
