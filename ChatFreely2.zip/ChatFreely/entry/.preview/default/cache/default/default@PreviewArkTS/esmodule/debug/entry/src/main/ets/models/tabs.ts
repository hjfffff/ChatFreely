export class BottomTabBarModel {
    /**
     * 底部TabBar的数据模型类
     */
    title: string = '';
    name: string = '';
    icon: ResourceStr = '';
    selectIcon: ResourceStr = '';
    static initData(): BottomTabBarModel[] {
        /**
         * 初始化底部Tab组件数据
         * 免费SVG图片
         * @returns
         */
        let data: BottomTabBarModel[] = [{
                icon: { "id": 16777254, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" },
                name: 'chat',
                title: '畅聊',
                selectIcon: { "id": 16777241, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" }
            }, {
                icon: { "id": 16777291, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" },
                name: 'connect',
                title: '联系人',
                selectIcon: { "id": 16777220, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" }
            }, {
                icon: { "id": 16777293, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" },
                name: 'space',
                title: '发现',
                selectIcon: { "id": 16777230, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" }
            }, {
                icon: { "id": 16777236, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" },
                name: 'my',
                title: '我的',
                selectIcon: { "id": 16777248, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" }
            }];
        return data;
    }
}
