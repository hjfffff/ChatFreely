export interface TokenResp {
    access_token: string;
    expires_in: number;
    error_description: string;
}
export class ReqData {
    messages: ReqMessage[];
    system: string;
    // max_output_tokens: number = 2000;
    // response_format: string = 'json_object'
    constructor(messages: ReqMessage[], system: string) {
        this.messages = messages;
        this.system = system;
    }
}
export class ReqMessage {
    role: string; // user
    content: string; // 问题的内容
    constructor(role: string, content: string) {
        this.role = role;
        this.content = content;
    }
}
export interface RespMessage {
    // object: string;
    result: string;
}
