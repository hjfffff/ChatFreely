import http from "@ohos:net.http";
import { ReqData } from "@normalized:N&&&entry/src/main/ets/models/ai&";
import type { ReqMessage, RespMessage, TokenResp } from "@normalized:N&&&entry/src/main/ets/models/ai&";
import Constants from "@normalized:N&&&entry/src/main/ets/utils/Constants&";
const req = http.createHttp(); // 初始化一个请求对象
/**
 * 调用AI大模型的接口： 获取access_token
 */
export async function requestToken() {
    // https://aip.baidubce.com/oauth/2.0/token
    try {
        // 给req对象，配置请求参数
        let config: http.HttpRequestOptions = {
            // method: http.RequestMethod.POST, // 设置请求方法
            method: http.RequestMethod.GET,
            extraData: '',
            header: {
                ContentType: 'application/json' // 设置请求头
            },
            connectTimeout: 10000,
            readTimeout: 10000,
            expectDataType: http.HttpDataType.OBJECT // 返回数据转换为对象（object）
        };
        // 发送请求，调用API接口
        // const res =await req.request('https://aip.baidubce.com/oauth/2.0/token?grant_type=client_credentials&client_id=', config)
        const res = await req.request(`https://aip.baidubce.com/oauth/2.0/token?client_id=${Constants.CLIENT_ID}&client_secret=${Constants.CLIENT_SECRET}&grant_type=client_credentials`, config);
        console.log("输出1：" + res.result);
        // 把返回的数据转换为，我们自己定义对象
        const result = res.result as TokenResp;
        return result;
    }
    catch (err) {
        console.log("输出：报错信息 " + JSON.stringify(err));
        return Promise.reject(err);
    }
}
/**
 * 调用AI的接口，得到一个AI的回答
 * @param data
 * @param token
 * @returns
 */
export async function requestMessage(data: ReqMessage, token: string) {
    try {
        // 组装请求配置
        let reqData: ReqData = new ReqData([data], '你是一个无所不知的答题助手，用最精简的语音回答用户的问题，最好1句话就给出答案；最多也不超过3句话。');
        let config: http.HttpRequestOptions = {
            method: http.RequestMethod.POST,
            extraData: reqData,
            header: {
                ContentType: 'application/json'
            },
            connectTimeout: 60000,
            readTimeout: 60000,
            expectDataType: http.HttpDataType.OBJECT // 自动将res.result转换为对象
        };
        console.log("输出：ttt " + token);
        const res = await req.request('https://aip.baidubce.com/rpc/2.0/ai_custom/v1/wenxinworkshop/chat/completions?access_token=' + token, config);
        const res2 = res.result as RespMessage;
        // console.log("输出： "+ JSON.stringify(res));
        console.log("输出： " + res2.result);
        return res2;
    }
    catch (error) {
        console.log("输出：报错信息 " + JSON.stringify(error));
        return Promise.reject(error);
    }
}
