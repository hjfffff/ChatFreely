/**
 * 处理时间戳的工具函数
 * 把时间变成一个字符串 2024年 12月 22日 14：23
 * @param time
 * @returns
 */
export function transTime(time: number) {
    const dateobj = new Date(time);
    const year = dateobj.getFullYear();
    const month = dateobj.getMonth();
    const date = dateobj.getDate();
    const hours = dateobj.getHours();
    const minutes = dateobj.getMinutes();
    if (year === new Date().getFullYear()) {
        //今年
        if (month === new Date().getMonth()) {
            //这个月
            if (date === new Date().getDate()) {
                //当天
                return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
            }
            else {
                return `${new Date().getDate() - date}天前`;
            }
        }
        else {
            return `${month}月${date}日`;
        }
    }
    else {
        return `${year}年${month}月${date}日`;
    }
}
