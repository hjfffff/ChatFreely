export enum VoiceStatusEnum {
    Cancel = 0,
    Recording = 1,
    Transfer = 2
}
