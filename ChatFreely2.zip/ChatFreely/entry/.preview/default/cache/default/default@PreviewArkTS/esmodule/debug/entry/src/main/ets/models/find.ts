export class FindList {
    static FiList(): FindList[] {
        throw new Error('Method not implemented.');
    }
    name: string = ''; //功能头像
    img: ResourceStr = ''; //功能名称
    id: string = ''; //功能id
    public static Find(): FindList[] {
        let data: FindList[] = [{
                name: '视频号',
                img: { "id": 16777320, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" },
                id: '1'
            }, {
                name: '直播',
                img: { "id": 16777318, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" },
                id: '2'
            }, {
                name: '扫一扫',
                img: { "id": 16777310, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" },
                id: '3'
            }, {
                name: '听一听',
                img: { "id": 16777312, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" },
                id: '4'
            }, {
                name: '看一看',
                img: { "id": 16777319, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" },
                id: '5'
            }, {
                name: '搜一搜',
                img: { "id": 16777313, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" },
                id: '6'
            }, {
                name: '附近',
                img: { "id": 16777315, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" },
                id: '7'
            }, {
                name: '购物',
                img: { "id": 16777311, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" },
                id: '8'
            }, {
                name: '游戏',
                img: { "id": 16777317, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" },
                id: '9'
            }];
        return data;
    }
}
