if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface PreviewImage_Params {
    controller?: CustomDialogController;
    url?: ResourceStr;
    type?: MessageTypeEnum;
}
import { MessageTypeEnum } from "@normalized:N&&&entry/src/main/ets/models/msg&";
class PreviewImage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.controller = undefined;
        this.url = '' // 图片或者视频的路径
        ;
        this.type = MessageTypeEnum.IMAGE;
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: PreviewImage_Params) {
        if (params.controller !== undefined) {
            this.controller = params.controller;
        }
        if (params.url !== undefined) {
            this.url = params.url;
        }
        if (params.type !== undefined) {
            this.type = params.type;
        }
    }
    updateStateVars(params: PreviewImage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private controller: CustomDialogController;
    setController(ctr: CustomDialogController) {
        this.controller = ctr;
    }
    private url: ResourceStr; // 图片或者视频的路径
    private type: MessageTypeEnum;
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/components/PreviewImage.ets(9:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor(Color.Black);
            Column.justifyContent(FlexAlign.Center);
            Column.onClick(() => {
                this.controller.close();
            });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.type === MessageTypeEnum.IMAGE) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Image.create(this.url);
                        Image.debugLine("entry/src/main/ets/components/PreviewImage.ets(11:9)", "entry");
                        Image.width('100%');
                    }, Image);
                });
            }
            else if (this.type === MessageTypeEnum.VIDEO) {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Video.create({
                            src: this.url
                        });
                        Video.debugLine("entry/src/main/ets/components/PreviewImage.ets(14:9)", "entry");
                        Video.loop(true);
                        Video.autoPlay(true);
                        Video.controls(false);
                        Video.width('100%');
                        Video.height('100%');
                    }, Video);
                });
            }
            else {
                this.ifElseBranchUpdateFunction(2, () => {
                });
            }
        }, If);
        If.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
export default PreviewImage;
