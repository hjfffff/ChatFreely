import preferences from "@ohos:data.preferences";
import type { MessageModel } from '../models/msg';
import { UserModel } from "@normalized:N&&&entry/src/main/ets/models/users&";
import emitter from "@ohos:events.emitter";
export class AppStorageUtils {
    static context: Context;
    //存放数据的key
    static TOKEN_KEY1: string = 'my_token_key1';
    static TOKEN_KEY2: string = 'my_token_key2';
    static chat_key: string = 'FREELY_CHAT';
    static init(context: Context) {
        AppStorageUtils.context = context;
    }
    // 获取某个联系人的聊天仓库
    static getUserStore(userId: string) {
        // 为了不和其他存储冲突，添加一个首选项存储标识chat_key拼接userId
        return preferences.getPreferencesSync(AppStorageUtils.context, { name: `${AppStorageUtils.chat_key}_${userId}` });
    }
    // 某个人的仓库添加一条消息
    static async addChatMessage(userId: string, message: MessageModel) {
        const store = AppStorageUtils.getUserStore(userId);
        store.putSync(message.id, JSON.stringify(message));
        await store.flush();
        //   线程通信：发布者
        emitter.emit(AppStorageUtils.chat_key);
    }
    // 获取某个人的所有信息
    static getChatMessage(userId: string) {
        const store = AppStorageUtils.getUserStore(userId);
        const all = store.getAllSync() as object;
        if (all) {
            const list = Object.values(all).map((item: string) => JSON.parse(item) as MessageModel);
            // 聊天列表是时间倒序显示的
            list.sort((a, b) => a.sendTime - b.sendTime);
            return list;
        }
        return [];
    }
    // 移除某个人的一条消息
    static async removeChatMessage(userId: string, messageId: string) {
        const store = AppStorageUtils.getUserStore(userId);
        store.deleteSync(messageId);
        await store.flush();
        //   线程通信：发布者
        emitter.emit(AppStorageUtils.chat_key);
    }
    // 移除某个人的所有消息
    static async removeChatAllMessage(userId: string) {
        preferences.deletePreferences(AppStorageUtils.context, { name: `${AppStorageUtils.chat_key}_${userId}` });
        //   线程通信：发布者
        emitter.emit(AppStorageUtils.chat_key);
    }
    // 获取所有人的最后一条消息
    static getAllChatLastMessage() {
        const lastList: MessageModel[] = [];
        UserModel.initData().forEach(user => {
            const chatList = AppStorageUtils.getChatMessage(user.id);
            if (chatList.length) {
                lastList.push(chatList[chatList.length - 1]); //  [1, 2, 77, 44, 23]
            }
        });
        lastList.sort((a, b) => a.sendTime - b.sendTime);
        return lastList;
    }
    /**
     * 获取首选项
     */
    static getPreStore() {
        return preferences.getPreferences(AppStorageUtils.context, { name: AppStorageUtils.TOKEN_KEY2 });
    }
    /**
     * 存放token数据
     * @param token
     */
    static async setToken(token: string) {
        //存储到内存中
        AppStorage.setOrCreate(AppStorageUtils.TOKEN_KEY1, token);
        //存到磁盘里
        const store = await AppStorageUtils.getPreStore();
        await store.putSync('TOKEN', token);
        //刷新
        await store.flush();
    }
    /**
     * 获取token数据
     * @param token
     */
    static async getToken() {
        // 获取token
        const store = await AppStorageUtils.getPreStore();
        const res = await store.getSync('TOKEN', '');
        return res.toString();
    }
}
