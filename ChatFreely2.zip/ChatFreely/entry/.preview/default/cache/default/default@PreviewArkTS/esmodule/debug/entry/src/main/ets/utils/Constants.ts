export default class Constants {
    public static CLIENT_ID: string = 'QRF9baljvwp2GERoe4ShWjMs';
    public static CLIENT_SECRET: string = 'dbT1dI3MsIf22uscXUE5yVGTLmyh8KtE';
}
