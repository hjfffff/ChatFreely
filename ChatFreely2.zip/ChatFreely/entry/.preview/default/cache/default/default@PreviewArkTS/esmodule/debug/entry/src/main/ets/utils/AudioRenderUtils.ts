import audio from "@ohos:multimedia.audio";
import fileIo from "@ohos:file.fs";
export class AudioRenderUtils {
    //播放PCM的工具类
    //准备播放器的配置信息
    static audioStreamInfo: audio.AudioStreamInfo = {
        samplingRate: audio.AudioSamplingRate.SAMPLE_RATE_48000,
        channels: audio.AudioChannel.CHANNEL_2,
        sampleFormat: audio.AudioSampleFormat.SAMPLE_FORMAT_S16LE,
        encodingType: audio.AudioEncodingType.ENCODING_TYPE_RAW
    };
    static audioRendererInfo: audio.AudioRendererInfo = {
        usage: audio.StreamUsage.STREAM_USAGE_VOICE_COMMUNICATION,
        rendererFlags: 0
    };
    static audioRendererOptions: audio.AudioRendererOptions = {
        streamInfo: AudioRenderUtils.audioStreamInfo,
        rendererInfo: AudioRenderUtils.audioRendererInfo
    };
    //初始化播放器
    static renderPlayer: audio.AudioRenderer;
    //要进行播放的文件
    static renderFile: fileIo.File;
    //播放的文件总的大小
    static maxSize: number = 0;
    //已经播放的字节大小(播放的位置)
    static renderSize: number = 0;
    //结束语音播放后 回调函数
    static callback: () => void;
    //初始化播放器
    static async init() {
        //创建播放器对象
        AudioRenderUtils.renderPlayer = await audio.createAudioRenderer(AudioRenderUtils.audioRendererOptions);
        //监听播放事件的回调函数
        AudioRenderUtils.renderPlayer.on('writeData', (buffer: ArrayBuffer) => {
            //播放的底层原理： 不断读取语音文件中的数据，来进行渲染 一直把整个文件数据渲染出来
            if (AudioRenderUtils.renderFile) { //如果语音文件存在
                fileIo.readSync(AudioRenderUtils.renderFile.fd, buffer, {
                    offset: AudioRenderUtils.renderSize,
                    length: buffer.byteLength
                });
                AudioRenderUtils.renderSize += buffer.byteLength;
                //判断是否播放结束
                if (AudioRenderUtils.renderSize >= AudioRenderUtils.maxSize) { //播放结束
                    //读取文件停止
                    fileIo.closeSync(AudioRenderUtils.renderFile.fd);
                    //播放器停止
                    AudioRenderUtils.stop();
                }
            }
        });
    }
    /**
     *
     * 播放语音
     * @param filePath语音文件
     * @param callback1当播放语音开始后，自动调用的函数
     * @param callback2当停止播放语音，后自动调用的函数
     */
    static async start(filePath: string, callback1?: () => void, callback2?: () => void) {
        //把上一次的播放停止掉
        await AudioRenderUtils.stop();
        //赋值
        AudioRenderUtils.renderFile = fileIo.openSync(filePath, fileIo.OpenMode.READ_WRITE);
        AudioRenderUtils.maxSize = (await fileIo.stat(AudioRenderUtils.renderFile.fd)).size;
        if (callback2) {
            AudioRenderUtils.callback = callback2;
        }
        //播放语音
        if (callback1) {
            callback1();
        }
        AudioRenderUtils.renderPlayer.start();
    }
    static async stop() {
        // 遵守状态机：只有running才能stop
        if (AudioRenderUtils.renderPlayer && AudioRenderUtils.renderPlayer.state === audio.AudioState.STATE_RUNNING) {
            await AudioRenderUtils.renderPlayer.stop();
            // 调用回调函数
            AudioRenderUtils.callback && AudioRenderUtils.callback();
            AudioRenderUtils.maxSize = 0;
            AudioRenderUtils.renderSize = 0;
        }
    }
    // 释放
    static async release() {
        if (AudioRenderUtils.renderPlayer) {
            await AudioRenderUtils.stop(); //先停，可能还在播放
            await AudioRenderUtils.renderPlayer.release(); // 释放
        }
    }
}
