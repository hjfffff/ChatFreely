if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface MessageDetail_Params {
    //定义一个删除聊天记录的函数
    delMessage?: (msgId: string) => void;
    // 消息数据
    item?: MessageModel;
    currentUser?: UserModel;
    showPopupMenu?: boolean;
    popupMenuList?: PopupMenu[];
    previewMedia?: () => void;
    audioState?: AnimationStatus;
    //视频controller
    videoController?: VideoController;
}
import { MessageModel, MessageTypeEnum } from "@normalized:N&&&entry/src/main/ets/models/msg&";
import type { MessageInterface } from "@normalized:N&&&entry/src/main/ets/models/msg&";
import { PopupMenu } from "@normalized:N&&&entry/src/main/ets/models/PopupMenu&";
import { UserModel } from "@normalized:N&&&entry/src/main/ets/models/users&";
import { AudioRenderUtils } from "@normalized:N&&&entry/src/main/ets/utils/AudioRenderUtils&";
import { FileUtils } from "@normalized:N&&&entry/src/main/ets/utils/FileUtils&";
class MessageDetail extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.delMessage = () => { };
        this.item = new MessageModel({} as MessageInterface);
        this.currentUser = UserModel.getCurrentUser() // 当前登录的用户
        ;
        this.__showPopupMenu = new ObservedPropertySimplePU(false //是否悬浮
        , this, "showPopupMenu");
        this.__popupMenuList = new ObservedPropertyObjectPU([
            new PopupMenu('收藏', { "id": 16777237, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" }),
            new PopupMenu('转文本', { "id": 16777255, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" }),
            new PopupMenu('删除', { "id": 16777240, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" }, () => {
                console.log('TestOnclick函数');
                //删除语音信息对应的语音文件
                if (this.item.sourceFilePath) {
                    FileUtils.delFilePath(this.item.sourceFilePath);
                }
                this.delMessage(this.item.id);
            }),
            new PopupMenu('引用', { "id": 16777284, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" }),
            new PopupMenu('多选', { "id": 16777243, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" })
        ], this, "popupMenuList");
        this.previewMedia = () => { } //定义一个函数，预览图片和视频的，由父组件传入
        ;
        this.__audioState = new ObservedPropertySimplePU(AnimationStatus.Initial //播放状态 随着语音播放或者停止来修改状态
        //获取语音显示
        , this, "audioState");
        this.videoController = new VideoController();
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: MessageDetail_Params) {
        if (params.delMessage !== undefined) {
            this.delMessage = params.delMessage;
        }
        if (params.item !== undefined) {
            this.item = params.item;
        }
        if (params.currentUser !== undefined) {
            this.currentUser = params.currentUser;
        }
        if (params.showPopupMenu !== undefined) {
            this.showPopupMenu = params.showPopupMenu;
        }
        if (params.popupMenuList !== undefined) {
            this.popupMenuList = params.popupMenuList;
        }
        if (params.previewMedia !== undefined) {
            this.previewMedia = params.previewMedia;
        }
        if (params.audioState !== undefined) {
            this.audioState = params.audioState;
        }
        if (params.videoController !== undefined) {
            this.videoController = params.videoController;
        }
    }
    updateStateVars(params: MessageDetail_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__showPopupMenu.purgeDependencyOnElmtId(rmElmtId);
        this.__popupMenuList.purgeDependencyOnElmtId(rmElmtId);
        this.__audioState.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__showPopupMenu.aboutToBeDeleted();
        this.__popupMenuList.aboutToBeDeleted();
        this.__audioState.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    //定义一个删除聊天记录的函数
    private delMessage: (msgId: string) => void;
    // 消息数据
    private item: MessageModel;
    private currentUser: UserModel; // 当前登录的用户
    private __showPopupMenu: ObservedPropertySimplePU<boolean>; //是否悬浮
    get showPopupMenu() {
        return this.__showPopupMenu.get();
    }
    set showPopupMenu(newValue: boolean) {
        this.__showPopupMenu.set(newValue);
    }
    private __popupMenuList: ObservedPropertyObjectPU<PopupMenu[]>;
    get popupMenuList() {
        return this.__popupMenuList.get();
    }
    set popupMenuList(newValue: PopupMenu[]) {
        this.__popupMenuList.set(newValue);
    }
    private previewMedia: () => void; //定义一个函数，预览图片和视频的，由父组件传入
    aboutToAppear(): void {
        // this.item.sendUser = this.currentUser  // 模拟数据： 所有的消息都是当前登录用户发送的
    }
    getPopupMenus(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            GridRow.create({ columns: 5 });
            GridRow.debugLine("entry/src/main/ets/components/MessageDetail.ets(44:5)", "entry");
            GridRow.width(300);
            GridRow.padding({
                top: 15,
                left: 10
            });
        }, GridRow);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    //渲染每一列，菜单
                    GridCol.create();
                    GridCol.debugLine("entry/src/main/ets/components/MessageDetail.ets(47:9)", "entry");
                    //渲染每一列，菜单
                    GridCol.onClick(() => {
                        if (item.itemClick) { //如果菜单有点击事件的函数，则调用
                            item.itemClick();
                        }
                    });
                }, GridCol);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Column.create({ space: 6 });
                    Column.debugLine("entry/src/main/ets/components/MessageDetail.ets(48:11)", "entry");
                    Column.height(60);
                }, Column);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Image.create(item.icon);
                    Image.debugLine("entry/src/main/ets/components/MessageDetail.ets(49:13)", "entry");
                    Image.fillColor({ "id": 16777276, "type": 10001, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" });
                    Image.width(18);
                    Image.height(18);
                }, Image);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(item.title);
                    Text.debugLine("entry/src/main/ets/components/MessageDetail.ets(53:13)", "entry");
                    Text.fontColor({ "id": 16777276, "type": 10001, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" });
                    Text.fontSize(14);
                }, Text);
                Text.pop();
                Column.pop();
                //渲染每一列，菜单
                GridCol.pop();
            };
            this.forEachUpdateFunction(elmtId, this.popupMenuList, forEachItemGenFunction);
        }, ForEach);
        ForEach.pop();
        GridRow.pop();
    }
    getTextMessage(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(this.item.messageContent);
            Text.debugLine("entry/src/main/ets/components/MessageDetail.ets(76:5)", "entry");
            Text.backgroundColor(this.currentUser.id === this.item.sendUser.id ? { "id": 16777269, "type": 10001, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" } : { "id": 16777276, "type": 10001, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" });
            Text.fontColor({ "id": 16777271, "type": 10001, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" });
            Text.padding(10);
            Text.lineHeight(24);
            Text.margin({
                left: 10,
                right: 10
            });
            Text.borderRadius(5);
        }, Text);
        Text.pop();
    }
    //获取语音宽度
    getAudioWidth() {
        let minWidth: number = 20;
        let maxWidth: number = 90;
        let calWidth: number = minWidth + (100 * this.item.sourceDuration / 60);
        if (calWidth > maxWidth) {
            return maxWidth + '%';
        }
        return calWidth + '%';
    }
    private __audioState: ObservedPropertySimplePU<AnimationStatus>; //播放状态 随着语音播放或者停止来修改状态
    get audioState() {
        return this.__audioState.get();
    }
    set audioState(newValue: AnimationStatus) {
        this.__audioState.set(newValue);
    }
    //获取语音显示
    getAudioContent(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/components/MessageDetail.ets(105:5)", "entry");
            Column.alignItems(this.currentUser.id === this.item.sendUser.id ? HorizontalAlign.End : HorizontalAlign.Start);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 5 });
            Row.debugLine("entry/src/main/ets/components/MessageDetail.ets(107:7)", "entry");
            Row.width(this.getAudioWidth());
            Row.backgroundColor(this.currentUser.id === this.item.sendUser.id ? { "id": 16777262, "type": 10001, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" } : { "id": 16777276, "type": 10001, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" });
            Row.justifyContent(this.currentUser.id === this.item.sendUser.id ? FlexAlign.End : FlexAlign.Start);
            Row.height(40);
            Row.padding({
                left: 10,
                right: 10
            });
            Row.margin({
                left: 10,
                right: 10
            });
            Row.borderRadius(4);
            Row.direction(this.currentUser.id === this.item.sendUser.id ? Direction.Ltr : Direction.Rtl);
            Row.onClick(() => {
                // 点击了语音信息，播放语音
                AudioRenderUtils.start(this.item.sourceFilePath, () => {
                    this.audioState = AnimationStatus.Running; //当语音播放时，设置状态为running
                }, () => {
                    this.audioState = AnimationStatus.Stopped; //当语音停止时，设置状态为Stopped
                });
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`${this.item.sourceDuration}"`);
            Text.debugLine("entry/src/main/ets/components/MessageDetail.ets(108:9)", "entry");
            Text.textAlign(TextAlign.Center);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // Image($r("app.media.ic_public_recorder"))// 固定死的图片，没有播放动画效果
            //   .width(20)
            //   .height(20)
            //   .rotate({ // 图片的旋转
            //     // 当前用户发送的语音 和 联系人发送的语音 图片需要旋转180度
            //     angle: this.currentUser.id === this.item.sendUser.id ? 180 : 0
            //   })
            // 有播放语音效果的动画
            ImageAnimator.create();
            ImageAnimator.debugLine("entry/src/main/ets/components/MessageDetail.ets(118:9)", "entry");
            // Image($r("app.media.ic_public_recorder"))// 固定死的图片，没有播放动画效果
            //   .width(20)
            //   .height(20)
            //   .rotate({ // 图片的旋转
            //     // 当前用户发送的语音 和 联系人发送的语音 图片需要旋转180度
            //     angle: this.currentUser.id === this.item.sendUser.id ? 180 : 0
            //   })
            // 有播放语音效果的动画
            ImageAnimator.images([
                //每一帧的图片，快速轮播得到的动画
                { src: { "id": 16777300, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" } },
                { src: { "id": 16777301, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" } },
                { src: { "id": 16777299, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" } },
                { src: { "id": 16777300, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" } },
            ]);
            // Image($r("app.media.ic_public_recorder"))// 固定死的图片，没有播放动画效果
            //   .width(20)
            //   .height(20)
            //   .rotate({ // 图片的旋转
            //     // 当前用户发送的语音 和 联系人发送的语音 图片需要旋转180度
            //     angle: this.currentUser.id === this.item.sendUser.id ? 180 : 0
            //   })
            // 有播放语音效果的动画
            ImageAnimator.iterations(-1);
            // Image($r("app.media.ic_public_recorder"))// 固定死的图片，没有播放动画效果
            //   .width(20)
            //   .height(20)
            //   .rotate({ // 图片的旋转
            //     // 当前用户发送的语音 和 联系人发送的语音 图片需要旋转180度
            //     angle: this.currentUser.id === this.item.sendUser.id ? 180 : 0
            //   })
            // 有播放语音效果的动画
            ImageAnimator.state(this.audioState);
            // Image($r("app.media.ic_public_recorder"))// 固定死的图片，没有播放动画效果
            //   .width(20)
            //   .height(20)
            //   .rotate({ // 图片的旋转
            //     // 当前用户发送的语音 和 联系人发送的语音 图片需要旋转180度
            //     angle: this.currentUser.id === this.item.sendUser.id ? 180 : 0
            //   })
            // 有播放语音效果的动画
            ImageAnimator.duration(300);
            // Image($r("app.media.ic_public_recorder"))// 固定死的图片，没有播放动画效果
            //   .width(20)
            //   .height(20)
            //   .rotate({ // 图片的旋转
            //     // 当前用户发送的语音 和 联系人发送的语音 图片需要旋转180度
            //     angle: this.currentUser.id === this.item.sendUser.id ? 180 : 0
            //   })
            // 有播放语音效果的动画
            ImageAnimator.fillMode(FillMode.None);
            // Image($r("app.media.ic_public_recorder"))// 固定死的图片，没有播放动画效果
            //   .width(20)
            //   .height(20)
            //   .rotate({ // 图片的旋转
            //     // 当前用户发送的语音 和 联系人发送的语音 图片需要旋转180度
            //     angle: this.currentUser.id === this.item.sendUser.id ? 180 : 0
            //   })
            // 有播放语音效果的动画
            ImageAnimator.width(20);
            // Image($r("app.media.ic_public_recorder"))// 固定死的图片，没有播放动画效果
            //   .width(20)
            //   .height(20)
            //   .rotate({ // 图片的旋转
            //     // 当前用户发送的语音 和 联系人发送的语音 图片需要旋转180度
            //     angle: this.currentUser.id === this.item.sendUser.id ? 180 : 0
            //   })
            // 有播放语音效果的动画
            ImageAnimator.height(20);
            // Image($r("app.media.ic_public_recorder"))// 固定死的图片，没有播放动画效果
            //   .width(20)
            //   .height(20)
            //   .rotate({ // 图片的旋转
            //     // 当前用户发送的语音 和 联系人发送的语音 图片需要旋转180度
            //     angle: this.currentUser.id === this.item.sendUser.id ? 180 : 0
            //   })
            // 有播放语音效果的动画
            ImageAnimator.rotate({
                // 当前用户发送的语音 和 联系人发送的语音 图片需要旋转180度
                angle: this.currentUser.id === this.item.sendUser.id ? 180 : 0
            });
        }, ImageAnimator);
        Row.pop();
        Column.pop();
    }
    getImageContent(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/components/MessageDetail.ets(166:5)", "entry");
            Column.width('40%');
            Column.margin({
                left: 10,
                right: 10
            });
            Column.onClick(() => {
                this.previewMedia;
            });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //
            Image.create('file://' + this.item.sourceFilePath);
            Image.debugLine("entry/src/main/ets/components/MessageDetail.ets(168:7)", "entry");
            //
            Image.borderRadius(4);
            //
            Image.width('100%');
            //
            Image.enabled(false);
        }, Image);
        Column.pop();
    }
    //视频controller
    private videoController: VideoController;
    getVideoContent(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/components/MessageDetail.ets(188:5)", "entry");
            Column.margin({
                left: 10,
                right: 10
            });
            Column.onClick(() => {
                this.previewMedia(); //预览视频
            });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create();
            Stack.debugLine("entry/src/main/ets/components/MessageDetail.ets(189:7)", "entry");
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Video.create({
                src: 'file://' + this.item.sourceFilePath,
                controller: this.videoController
            });
            Video.debugLine("entry/src/main/ets/components/MessageDetail.ets(190:9)", "entry");
            Video.controls(false);
            Video.width(100);
            Video.height(150);
            Video.borderRadius(4);
            Video.id(this.item.id);
            Video.onPrepared(() => {
                this.videoController.setCurrentTime(0.5); //让视频直接跳转到0.5s的位置
            });
        }, Video);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777289, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/components/MessageDetail.ets(202:9)", "entry");
            Image.width(30);
            Image.height(30);
            Image.fillColor({ "id": 16777257, "type": 10001, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" });
        }, Image);
        Stack.pop();
        Column.pop();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/components/MessageDetail.ets(218:5)", "entry");
            Row.width('100%');
            Row.padding({
                left: 20,
                right: 20
            });
            Row.alignItems(VerticalAlign.Top);
            Row.direction(this.currentUser.id === this.item.sendUser.id ? Direction.Rtl : Direction.Ltr);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // Image($r('app.media.icon10'))  // 用户头像
            Image.create(this.item.sendUser.avatar);
            Image.debugLine("entry/src/main/ets/components/MessageDetail.ets(220:7)", "entry");
            // Image($r('app.media.icon10'))  // 用户头像
            Image.height(40);
            // Image($r('app.media.icon10'))  // 用户头像
            Image.width(40);
            // Image($r('app.media.icon10'))  // 用户头像
            Image.borderRadius(6);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/components/MessageDetail.ets(225:7)", "entry");
            Gesture.create(GesturePriority.Low);
            LongPressGesture.create();
            LongPressGesture.onAction(() => {
                this.showPopupMenu = true; //弹出悬浮层
            });
            LongPressGesture.pop();
            Gesture.pop();
            Row.layoutWeight(6);
            Row.justifyContent(this.currentUser.id === this.item.sendUser.id ? FlexAlign.End : FlexAlign.Start);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/components/MessageDetail.ets(226:9)", "entry");
            Column.bindPopup(this.showPopupMenu, {
                builder: { builder: this.getPopupMenus.bind(this) },
                enableArrow: true,
                popupColor: { "id": 16777266, "type": 10001, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" },
                backgroundBlurStyle: BlurStyle.NONE,
                onStateChange: (event) => {
                    this.showPopupMenu = false; //当手指点击了其他地方，改变了悬浮状态
                }
            });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.item.messageType === MessageTypeEnum.TEXT) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.getTextMessage.bind(this)() //渲染文本消息
                    ;
                });
            }
            else if (this.item.messageType === MessageTypeEnum.AUDIO) {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.getAudioContent.bind(this)();
                });
            }
            else if (this.item.messageType === MessageTypeEnum.IMAGE) {
                this.ifElseBranchUpdateFunction(2, () => {
                    this.getImageContent.bind(this)();
                });
            }
            else if (this.item.messageType === MessageTypeEnum.VIDEO) {
                this.ifElseBranchUpdateFunction(3, () => {
                    this.getVideoContent.bind(this)();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(4, () => {
                });
            }
        }, If);
        If.pop();
        Column.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create();
            Text.debugLine("entry/src/main/ets/components/MessageDetail.ets(256:7)", "entry");
            Text.layoutWeight(1);
        }, Text);
        Text.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
export default MessageDetail;
if (getPreviewComponentFlag()) {
    storePreviewComponents(1, "MessageDetail", new MessageDetail(undefined, {}));
    previewComponent();
}
else {
}
