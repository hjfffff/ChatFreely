if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface GnComp_Params {
}
interface NavComp_Params {
}
interface PersonalMessage_Params {
    GnList?: FeatureList[];
}
import { FeatureList } from "@normalized:N&&&entry/src/main/ets/models/me&";
export class PersonalMessage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__GnList = new ObservedPropertyObjectPU(FeatureList.GNList(), this, "GnList");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: PersonalMessage_Params) {
        if (params.GnList !== undefined) {
            this.GnList = params.GnList;
        }
    }
    updateStateVars(params: PersonalMessage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__GnList.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__GnList.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __GnList: ObservedPropertyObjectPU<FeatureList[]>;
    get GnList() {
        return this.__GnList.get();
    }
    set GnList(newValue: FeatureList[]) {
        this.__GnList.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/components/PersonalMessage.ets(10:5)", "entry");
        }, Column);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new 
                    //头像名称微信名
                    NavComp(this, {}, undefined, elmtId, () => { }, { page: "entry/src/main/ets/components/PersonalMessage.ets", line: 13, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {};
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
            }, { name: "NavComp" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/components/PersonalMessage.ets(15:7)", "entry");
            Column.width('100%');
            Column.height('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Divider.create();
            Divider.debugLine("entry/src/main/ets/components/PersonalMessage.ets(16:9)", "entry");
            Divider.strokeWidth(10);
            Divider.backgroundColor('#e6e6e6');
            Divider.opacity(0.3);
        }, Divider);
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new 
                    //服务
                    GnComp(this, {}, undefined, elmtId, () => { }, { page: "entry/src/main/ets/components/PersonalMessage.ets", line: 22, col: 9 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {};
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
            }, { name: "GnComp" });
        }
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Divider.create();
            Divider.debugLine("entry/src/main/ets/components/PersonalMessage.ets(24:9)", "entry");
            Divider.strokeWidth(10);
            Divider.backgroundColor('#e6e6e6');
            Divider.opacity(0.3);
        }, Divider);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //收藏、、、遍历、
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Row.create();
                    Row.debugLine("entry/src/main/ets/components/PersonalMessage.ets(31:11)", "entry");
                    Row.padding(15);
                    Row.width('100%');
                    Row.justifyContent(FlexAlign.SpaceBetween);
                }, Row);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Row.create({ space: 20 });
                    Row.debugLine("entry/src/main/ets/components/PersonalMessage.ets(32:13)", "entry");
                }, Row);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Image.create(item.fn);
                    Image.debugLine("entry/src/main/ets/components/PersonalMessage.ets(33:15)", "entry");
                    Image.aspectRatio(1);
                    Image.width(30);
                }, Image);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create(item.fc);
                    Text.debugLine("entry/src/main/ets/components/PersonalMessage.ets(36:15)", "entry");
                    Text.fontSize(18);
                }, Text);
                Text.pop();
                Row.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Image.create({ "id": 16777281, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" });
                    Image.debugLine("entry/src/main/ets/components/PersonalMessage.ets(41:13)", "entry");
                    Image.width(15);
                }, Image);
                Row.pop();
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Divider.create();
                    Divider.debugLine("entry/src/main/ets/components/PersonalMessage.ets(48:11)", "entry");
                    Divider.strokeWidth(1);
                    Divider.backgroundColor('#e6e6e6');
                    Divider.opacity(0.3);
                }, Divider);
            };
            this.forEachUpdateFunction(elmtId, this.GnList, forEachItemGenFunction);
        }, ForEach);
        //收藏、、、遍历、
        ForEach.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Divider.create();
            Divider.debugLine("entry/src/main/ets/components/PersonalMessage.ets(54:9)", "entry");
            Divider.strokeWidth(9);
            Divider.backgroundColor('#e6e6e6');
            Divider.opacity(0.3);
        }, Divider);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //设置
            Row.create();
            Row.debugLine("entry/src/main/ets/components/PersonalMessage.ets(59:9)", "entry");
            //设置
            Row.padding(15);
            //设置
            Row.width('100%');
            //设置
            Row.justifyContent(FlexAlign.SpaceBetween);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 20 });
            Row.debugLine("entry/src/main/ets/components/PersonalMessage.ets(60:11)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777309, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/components/PersonalMessage.ets(61:13)", "entry");
            Image.aspectRatio(1);
            Image.width(30);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('设置');
            Text.debugLine("entry/src/main/ets/components/PersonalMessage.ets(64:13)", "entry");
            Text.fontSize(18);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777281, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/components/PersonalMessage.ets(69:11)", "entry");
            Image.width(15);
        }, Image);
        //设置
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Divider.create();
            Divider.debugLine("entry/src/main/ets/components/PersonalMessage.ets(76:9)", "entry");
            Divider.strokeWidth(300);
            Divider.backgroundColor('#e6e6e6');
            Divider.opacity(0.3);
        }, Divider);
        Column.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
class NavComp extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: NavComp_Params) {
    }
    updateStateVars(params: NavComp_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/components/PersonalMessage.ets(94:5)", "entry");
            Row.margin({ top: 15 });
            Row.padding(10);
            Row.alignItems(VerticalAlign.Top);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/components/PersonalMessage.ets(95:7)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777297, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/components/PersonalMessage.ets(96:9)", "entry");
            Image.aspectRatio(1);
            Image.width(80);
            Image.padding(10);
            Image.borderRadius(10);
        }, Image);
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 5 });
            Column.debugLine("entry/src/main/ets/components/PersonalMessage.ets(102:7)", "entry");
            Column.width('100%');
            Column.padding(10);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('HH（已黑化');
            Text.debugLine("entry/src/main/ets/components/PersonalMessage.ets(103:9)", "entry");
            Text.fontSize(25);
            Text.fontWeight(FontWeight.Bold);
            Text.width('100%');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/components/PersonalMessage.ets(107:9)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('微信号： ZShen0720');
            Text.debugLine("entry/src/main/ets/components/PersonalMessage.ets(108:11)", "entry");
            Text.opacity(0.5);
            Text.width('65%');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 8 });
            Row.debugLine("entry/src/main/ets/components/PersonalMessage.ets(111:11)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777303, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/components/PersonalMessage.ets(112:13)", "entry");
            Image.width(20);
            Image.aspectRatio(1);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777281, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/components/PersonalMessage.ets(115:13)", "entry");
            Image.width(15);
        }, Image);
        Row.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 15 });
            Row.debugLine("entry/src/main/ets/components/PersonalMessage.ets(121:9)", "entry");
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('  + 状态  ');
            Text.debugLine("entry/src/main/ets/components/PersonalMessage.ets(122:11)", "entry");
            Text.fontSize(12);
            Text.borderWidth(0.8);
            Text.borderRadius(25);
            Text.padding(3);
            Text.opacity(0.5);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777302, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/components/PersonalMessage.ets(128:11)", "entry");
            Image.aspectRatio(1);
            Image.width(25);
        }, Image);
        Row.pop();
        Column.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
class GnComp extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: GnComp_Params) {
    }
    updateStateVars(params: GnComp_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/components/PersonalMessage.ets(151:5)", "entry");
            Row.padding(15);
            Row.width('100%');
            Row.justifyContent(FlexAlign.SpaceBetween);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 20 });
            Row.debugLine("entry/src/main/ets/components/PersonalMessage.ets(152:7)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777304, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/components/PersonalMessage.ets(153:9)", "entry");
            Image.aspectRatio(1);
            Image.width(30);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('服务');
            Text.debugLine("entry/src/main/ets/components/PersonalMessage.ets(156:9)", "entry");
            Text.fontSize(18);
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777281, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/components/PersonalMessage.ets(160:7)", "entry");
            Image.width(15);
        }, Image);
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
