export class FeatureList {
    fc: string = ''; //功能头像
    fn: ResourceStr = ''; //功能名称
    id: string = ''; //功能id
    public static GNList(): FeatureList[] {
        let data: FeatureList[] = [{
                fc: '收藏',
                fn: { "id": 16777305, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" },
                id: '1'
            }, {
                fc: '朋友圈',
                fn: { "id": 16777308, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" },
                id: '2'
            }, {
                fc: '卡包',
                fn: { "id": 16777306, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" },
                id: '3'
            }, {
                fc: '表情',
                fn: { "id": 16777307, "type": 20000, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" },
                id: '4'
            }];
        return data;
    }
}
