if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Index_Params {
    tabList?: BottomTabBarModel[];
    currentSelectIndex?: number;
}
import CompletionsHistory from "@normalized:N&&&entry/src/main/ets/components/CompletionsHistory&";
import ConnectUser from "@normalized:N&&&entry/src/main/ets/components/ConnectUser&";
import { PersonalMessage } from "@normalized:N&&&entry/src/main/ets/components/PersonalMessage&";
import type { TokenResp } from '../models/ai';
import { BottomTabBarModel } from "@normalized:N&&&entry/src/main/ets/models/tabs&";
import { AppStorageUtils } from "@normalized:N&&&entry/src/main/ets/utils/AppStorageUtils&";
import { requestToken } from "@normalized:N&&&entry/src/main/ets/utils/request&";
class Index extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__tabList = new ObservedPropertyObjectPU(BottomTabBarModel.initData() // 底部TabBar显示的数据
        , this, "tabList");
        this.__currentSelectIndex = new ObservedPropertySimplePU(0 // 当前选中的 底部TabBar 的索引。
        , this, "currentSelectIndex");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Index_Params) {
        if (params.tabList !== undefined) {
            this.tabList = params.tabList;
        }
        if (params.currentSelectIndex !== undefined) {
            this.currentSelectIndex = params.currentSelectIndex;
        }
    }
    updateStateVars(params: Index_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__tabList.purgeDependencyOnElmtId(rmElmtId);
        this.__currentSelectIndex.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__tabList.aboutToBeDeleted();
        this.__currentSelectIndex.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __tabList: ObservedPropertyObjectPU<BottomTabBarModel[]>; // 底部TabBar显示的数据
    get tabList() {
        return this.__tabList.get();
    }
    set tabList(newValue: BottomTabBarModel[]) {
        this.__tabList.set(newValue);
    }
    private __currentSelectIndex: ObservedPropertySimplePU<number>; // 当前选中的 底部TabBar 的索引。
    get currentSelectIndex() {
        return this.__currentSelectIndex.get();
    }
    set currentSelectIndex(newValue: number) {
        this.__currentSelectIndex.set(newValue);
    }
    async aboutToAppear() {
        let token: string = await AppStorageUtils.getToken();
        if (!token || token.length < 1) {
            const tokenResp: TokenResp = await requestToken();
            if (tokenResp && tokenResp.access_token) {
                token = tokenResp.access_token;
            }
            console.log('输出1:' + token);
        }
        //存放全局应用里面去
        AppStorageUtils.setToken(token);
    }
    // 构建一个子组件
    CommonTabBar(item: BottomTabBarModel, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(34:5)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create(item.name === this.tabList[this.currentSelectIndex].name ? item.selectIcon : item.icon);
            Image.debugLine("entry/src/main/ets/pages/Index.ets(35:7)", "entry");
            Image.width(20);
            Image.height(20);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.title);
            Text.debugLine("entry/src/main/ets/pages/Index.ets(39:7)", "entry");
            Text.fontColor(item.name === this.tabList[this.currentSelectIndex].name ? { "id": 16777267, "type": 10001, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" } : { "id": 16777271, "type": 10001, params: [], "bundleName": "com.hjf.chatfreely", "moduleName": "entry" });
            Text.fontSize(12);
            Text.margin({
                top: 5
            });
        }, Text);
        Text.pop();
        Column.pop();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Tabs.create({ index: { value: this.currentSelectIndex, changeEvent: newValue => { this.currentSelectIndex = newValue; } } });
            Tabs.debugLine("entry/src/main/ets/pages/Index.ets(50:5)", "entry");
            Tabs.barPosition(BarPosition.End);
            Tabs.animationDuration(300);
        }, Tabs);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    TabContent.create(() => {
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            If.create();
                            if (this.currentSelectIndex == 0) {
                                this.ifElseBranchUpdateFunction(0, () => {
                                    {
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            if (isInitialRender) {
                                                let componentCall = new CompletionsHistory(this, {}, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 56, col: 13 });
                                                ViewPU.create(componentCall);
                                                let paramsLambda = () => {
                                                    return {};
                                                };
                                                componentCall.paramsGenerator_ = paramsLambda;
                                            }
                                            else {
                                                this.updateStateVarsOfChildByElmtId(elmtId, {});
                                            }
                                        }, { name: "CompletionsHistory" });
                                    }
                                });
                            }
                            else if (this.currentSelectIndex == 1) {
                                this.ifElseBranchUpdateFunction(1, () => {
                                    {
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            if (isInitialRender) {
                                                let componentCall = new ConnectUser(this, {}, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 58, col: 13 });
                                                ViewPU.create(componentCall);
                                                let paramsLambda = () => {
                                                    return {};
                                                };
                                                componentCall.paramsGenerator_ = paramsLambda;
                                            }
                                            else {
                                                this.updateStateVarsOfChildByElmtId(elmtId, {});
                                            }
                                        }, { name: "ConnectUser" });
                                    }
                                });
                            }
                            else if (this.currentSelectIndex == 3) {
                                this.ifElseBranchUpdateFunction(2, () => {
                                    {
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            if (isInitialRender) {
                                                let componentCall = new PersonalMessage(this, {}, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 60, col: 13 });
                                                ViewPU.create(componentCall);
                                                let paramsLambda = () => {
                                                    return {};
                                                };
                                                componentCall.paramsGenerator_ = paramsLambda;
                                            }
                                            else {
                                                this.updateStateVarsOfChildByElmtId(elmtId, {});
                                            }
                                        }, { name: "PersonalMessage" });
                                    }
                                });
                            }
                            else {
                                this.ifElseBranchUpdateFunction(3, () => {
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Text.create(item.title);
                                        Text.debugLine("entry/src/main/ets/pages/Index.ets(62:13)", "entry");
                                    }, Text);
                                    Text.pop();
                                });
                            }
                        }, If);
                        If.pop();
                    });
                    TabContent.tabBar({ builder: () => {
                            this.CommonTabBar.call(this, item);
                        } });
                    TabContent.debugLine("entry/src/main/ets/pages/Index.ets(53:9)", "entry");
                }, TabContent);
                TabContent.pop();
            };
            this.forEachUpdateFunction(elmtId, this.tabList, forEachItemGenFunction);
        }, ForEach);
        ForEach.pop();
        Tabs.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Index";
    }
}
registerNamedRoute(() => new Index(undefined, {}), "", { bundleName: "com.hjf.chatfreely", moduleName: "entry", pagePath: "pages/Index", pageFullPath: "entry/src/main/ets/pages/Index", integratedHsp: "false" });
